This is the loot table that is injected into the loot table you specified.
This means that the loot table will be generated along with the original loot
of the other loot table without overriding the original file.