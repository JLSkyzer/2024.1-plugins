This is the loot table that loot will be injected into from your own loot table.
For example, a valid loot table ID is minecraft:chests/spawn_bonus_chest, but this can also
contain loot tables from other mods.