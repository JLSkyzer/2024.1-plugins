A vanilla trim type uses vanilla trim materials and automatically sets its color through the atlas. You will need to provide a grayscale texture
in order for the coloring to be applied correctly. 

A custom trim type uses a fixed color instead with a custom trim material. It will look the same
on all armors with any of the chosen custom materials.