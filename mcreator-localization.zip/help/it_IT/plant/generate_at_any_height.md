Seleziona questa opzione per generare questa pianta a qualsiasi altezza, invece che sulla superficie del mondo.

Questa opzione dovrebbe essere abilitata per le piante che generano nel Nether.