Seleziona questa opzione per cambiare la tua pianta in una Tile entity.

Quando questa opzione è abilitata, sarai in grado di memorizzare dati (come i tag NBT) all'interno della tua pianta.

Non abilitare questa opzione a meno che non sia realmente necessaria per motivi di prestazioni.