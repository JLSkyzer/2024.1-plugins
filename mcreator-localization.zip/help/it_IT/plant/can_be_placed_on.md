Elenco dei blocchi su cui può essere posizionata la pianta.

NOTA: questo sostituirà la condizione di posizionamento del tipo di pianta.