Questo parametro controlla di quale colore apparirà la tua pianta sulle mappe.

Se è impostato su Predefinito, il colore sarà FOLIAGE.