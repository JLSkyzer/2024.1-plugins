Questo parametro determina l'effetto della pozione delle zuppe sospette preparate con questa pianta.

NOTA: devi aggiungere la pianta al tag item `minecraft:small_flowers` per poter creare zuppe sospette.