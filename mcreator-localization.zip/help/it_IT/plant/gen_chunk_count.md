Questo parametro controlla quante volte verrà generata una patch di pianta per pezzo.

Le piante non vengono generate individualmente, ma in patch.

Ad esempio, impostare questo valore su 1 NON significa che c'è solo una pianta in ogni pezzo; invece, ogni pezzo avrà (al massimo) un gruppo di queste piante.

Per questo motivo, impostare questo valore su un valore basso (4 o meno) è sufficiente per la maggior parte degli scopi.