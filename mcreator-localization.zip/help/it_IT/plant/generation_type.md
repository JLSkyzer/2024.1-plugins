Questo parametro controlla la frequenza con cui verrà generata la tua pianta. Se impostato su **Erba**, la pianta genererà più spesso.

NOTA: questo riguarda solo le piante statiche e doppie.