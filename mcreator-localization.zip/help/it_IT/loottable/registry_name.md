Fare clic sull'elenco a discesa e scegliere la "categoria" della loot table. Non definisce il tipo di loot table.

È per solo standardizzare i nomi delle loot table. Usa blocks/registry_name per esempio per le loot table dei blocchi.