Utilizza questo campo per definire su quali blocchi avverrà la generazione.

Se l'elenco è vuoto, questa opzione sarà disabilitata e potrà apparire su tutti i blocchi.