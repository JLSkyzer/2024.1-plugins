Usa questo campo per definire dove dovrebbe avvenire lo spawn.

Se l'elenco è vuoto, lo spawning sarà disabilitato.