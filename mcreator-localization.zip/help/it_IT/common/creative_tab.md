Questo è dove il blocco sarà in modalità creativa.

Utilizza le schede con il prefisso PERSONALIZZATO: per utilizzare le schede personalizzate.