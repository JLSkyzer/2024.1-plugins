Usa questo campo per definire i biomi, dove dovrebbe avvenire la deposizione delle uova.

Se l'elenco è vuoto, non verrà impostata alcuna restrizione sul bioma e lo sarà la deposizione delle uova si verificheranno in tutti i biomi.