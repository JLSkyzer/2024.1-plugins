La categoria di associazione delle chiavi è la categoria mostrata nella sezione controlli delle impostazioni di Minecraft.

Tutte le combinazioni di tasti appartenenti alla stessa categoria dovrebbero avere lo stesso tasto categoria.

Per impostare il nome della categoria, vai a **${l10n.t("tab.workspace")} -> ${l10n.t("workspace.category.localization")} -> ${l10n.t("workspace. ocalization.add_entry")}** e utilizzare `key.category.${data.keyBindingCategoryKey}` per il nome della voce e quindi imposta il valore al nome della categoria desiderato.