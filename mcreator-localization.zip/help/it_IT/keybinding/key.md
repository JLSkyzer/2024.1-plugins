Questo parametro definisce la chiave utilizzata per eseguire la procedura di associazione delle chiavi.

I giocatori possono sempre cambiarlo all'interno dei controlli.