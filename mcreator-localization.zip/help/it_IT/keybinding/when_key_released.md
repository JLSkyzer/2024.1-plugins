Questa procedura verrà eseguita quando il tasto selezionato viene rilasciato (dopo che il giocatore ha premuto il tasto).

È possibile utilizzare la dipendenza pressms per determinare per quanto tempo è stato premuto il tasto nelle procedure personalizzate.