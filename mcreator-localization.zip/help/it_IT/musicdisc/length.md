Lunghezza del disco musicale in tick. 20 tick equivale a secondo.

Questo parametro viene utilizzato per segnalare agli Allay di interrompere la loro danza quando il numero di ticks specificato in questo campo passa dall'inizio della riproduzione.
