Selezionare la musica che si desideri il disco riproduca all'interno del jukebox.

Al fine di supportare tutte le funzioni jukebox, come il suono che diventa più silenzioso all'aumentare della distanza, assicurarsi che il suono è in formato MONO.

Se hai intenzione di distribuire la mod, assicurati di avere i permessi per ridistribuire la musica che utilizzi!