Potenza della pietrarossa prodotto dal comparatore quando questo disco musicale è presente nel jukebox accanto ad esso.
