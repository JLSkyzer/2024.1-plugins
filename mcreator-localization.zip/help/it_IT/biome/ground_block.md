Questo parametro controlla il blocco che ricopre la superficie del bioma.

Generalmente, erba vanilla o personalizzata è utilizzato qui per la maggior parte dei biomi.

Questo blocco dovrebbe avere materiale GRASS ed essere etichettato in <b>minecraft:dirt</b> nei tag blocco per le mod Forge per piante e alberi per generare correttamente nel bioma.