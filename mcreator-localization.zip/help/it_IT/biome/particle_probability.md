La probabilità di generare particelle.

NOTA: Questo valore è diviso per 100 nel codice.