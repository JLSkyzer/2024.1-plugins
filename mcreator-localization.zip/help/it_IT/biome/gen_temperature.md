Questo parametro controlla la generazione del bioma e non il clima.

I biomi con temperatura simile si genereranno più vicini e competeranno per lo stesso posto nel mondo durante la generazione. Valori troppo simili comporteranno la mancata generazione di alcuni biomi.

Sebbene i valori da -2 a 2 siano validi, i biomi vanilla utilizzano solo valori compresi nell'intervallo da -1 a 1.

Vari biomi Vanilla dell'Overworld utilizzano questi intervalli di valori:

* da -1,0 a -0,45
* da -0,45 a -0,15
* da -0,15 a 0,2
* da 0,2 a 0,55
* da 0,5 a 1,0