Questo parametro controlla la temperatura climatica del bioma.

0.0 è come la Snowy Tundra, e 2.0 è come il Deserto.

* Valori inferiori a 0.15 faranno nevicare nel tuo bioma personalizzato
* I valori tra 0,15 e 1,5 faranno piovere nel tuo bioma
* Valori più grandi di 1.5 renderanno il tuo bioma arido (disattiva la pioggia, come nei deserti per esempio)