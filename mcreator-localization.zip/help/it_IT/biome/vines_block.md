Questo paremeter controlla il blocco usato per sostituire le viti.

Seleziona blocco aria per non avere viti.