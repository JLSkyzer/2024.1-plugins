Questo campo fornisce una stima di quanto la superficie Overworld sarebbe coperto da questo bioma. Funziona correttamente solo se i valori per i biomi sono compresi tra -1 e 1 dato che questa è l'uso di biomi Overworld.

Nel caso in cui il tuo bioma sia usato nelle grotte del Nether o Overworld, questa stima non è valida.

Quando si utilizzano i biomi in una dimensione personalizzata, la copertura dipende dalla quantità di biomi che la dimensione ha, e ai parametri di generazione dei biomi nella dimensione.