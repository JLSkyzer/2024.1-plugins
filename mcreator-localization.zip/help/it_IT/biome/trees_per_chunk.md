Questo parametro controlla il numero di alberi (il tipo che hai selezionato) per chunk di bioma.

Imposta a 0 per disattivare gli alberi.