Seleziona questa impostazione per avere Rovine oceaniche nel tuo bioma.
* NESSUNO: non verranno generate rovine oceaniche.
* FREDDO: verranno generate rovine oceaniche fatte di pietra
* CALDO: verranno generate rovine oceaniche fatte di arenaria