Le funzionalità predefinite sono funzionalità preconfigurate (funzionalità di Minecraft) che puoi utilizzare nel tuo bioma.
