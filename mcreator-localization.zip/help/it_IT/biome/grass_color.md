Questo parametro controlla il colore dell'erba all'interno del bioma.

Questo parametro cambia anche il colore di altre piante (fogliame).