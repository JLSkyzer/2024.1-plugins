Questo parametro controlla il blocco utilizzato per la frutta come le fave di cacao con gli alberi della giungla nel caso in cui siano abilitati gli alberi personalizzati.

Seleziona il blocco d'aria per disabilitare i frutti degli alberi.