Seleziona le entità che si genereranno naturalmente all'interno del tuo bioma.

Seleziona solo mob passivi o ostili. Non selezionare il giocatore o entità speciali qui in quanto questo potrebbe causare il crash del mondo quando si tenta di generare tali entità.