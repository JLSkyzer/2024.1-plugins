Questo parametro controlla il blocco sotterraneo sotto il livello di blocchi di terra.

Generalmente, terra vanilla o personalizzata è utilizzata qui per la maggior parte dei biomi.

Questo blocco dovrebbe essere etichettato in <b>minecraft:dirt</b> nei tag blocco per le mod Forge per piante e alberi per generare correttamente nel bioma.