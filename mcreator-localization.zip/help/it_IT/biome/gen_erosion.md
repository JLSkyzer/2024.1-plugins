L'erosione controlla quanto è eroso il terreno. I valori più piccoli descrivono i biomi che di solito generano nelle regioni del mondo più piatte.

I biomi con erosione simile si genereranno più vicini e competeranno per lo stesso posto nel mondo durante la generazione. Valori troppo simili comporteranno la mancata generazione di alcuni biomi.

Sebbene i valori da -2 a 2 siano validi, i biomi vanilla utilizzano solo valori compresi nell'intervallo da -1 a 1.

Vari biomi Vanilla dell'Overworld utilizzano questi intervalli di valori:

* da -1,0 a -0,78
* da -0,78 a -0,375
* da -0,375 a -0,2225
* -0,2225 a 0,05
* da 0,05 a 0,45
* da 0,45 a 0,5
* da 0,55 a 1,0