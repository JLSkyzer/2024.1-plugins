Questo parametro definisce l'altezza minima del tronco dell'albero quando viene generato.

Applicato solo se è selezionata la definizione personalizzata dell'albero.