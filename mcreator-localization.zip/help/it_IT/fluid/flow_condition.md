Questa condizione determina se il fluido può diffondersi da una determinata posizione.

Tieni presente che questo è influenzato anche da altre proprietà (pendii vicini, blocchi solidi ecc.).