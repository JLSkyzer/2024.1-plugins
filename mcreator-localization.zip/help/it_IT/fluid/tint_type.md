Questa opzione applica una tinta al fluido basata sui colori del bioma, simile a erba, foglie e acqua. Per ottenere risultati ottimali, il fluido dovrebbero utilizzare una texture in scala di grigi.

Il tipo di tinta influisce anche sulla texture autogenerata del secchio.