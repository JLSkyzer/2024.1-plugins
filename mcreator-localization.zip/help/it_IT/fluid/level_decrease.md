Questo parametro determina quanto diminuisce il livello di questo fluido per ogni blocco in cui si diffonde. Con valori più alti, il fluido coprirà un'area più piccola.

Questo valore è 1 per l'acqua e la lava nel Nether, 2 per la lava nell'Overworld.