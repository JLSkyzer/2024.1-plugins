Questo parametro determina quanti tick sono necessari affinché il fluido si diffonda in un altro blocco. Più alto è questo valore, più più lentamente il fluido si sposterà.

I valori predefiniti sono 5 per l'acqua, 30 per la lava nell'Overworld e 10 per la lava nel Nether.