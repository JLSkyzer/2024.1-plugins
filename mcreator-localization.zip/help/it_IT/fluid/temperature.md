Questa è la temperatura del fluido, misurata in Kelvin. Più alto è il valore, più il fluido sarà più caldo.

Il valore predefinito è 300K, che è intorno alla temperatura ambiente.