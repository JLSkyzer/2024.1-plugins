Permette ai mob di avere equipaggiamenti se il modello mob lo supporta.

Da sinistra a destra gli slot rappresentano la mano destra, poi la sinistra, poi la testa, corazza, gambali e stivali.