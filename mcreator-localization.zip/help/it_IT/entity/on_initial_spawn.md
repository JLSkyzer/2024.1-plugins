Attiva la procedura quando l'entità viene generata.

Tieni presente che alcune procedure potrebbero non funzionare correttamente in questo trigger durante la prima generazione del mondo.