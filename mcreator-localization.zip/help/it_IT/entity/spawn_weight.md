Questo parametro controlla la priorità che il mob ha sugli altri quando il gioco sceglie quale mob generare.

Un peso più elevato significa che più mob spawn nel gioco creeranno questo mob. Rendilo più basso per gli animali, rispetto ai mostri.

Il sistema del peso di spawn è spiegato in modo approfondito [qui](https://mcreator.net/wiki/mob-spawning-parameters)