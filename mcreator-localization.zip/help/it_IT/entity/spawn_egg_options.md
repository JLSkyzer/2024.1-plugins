Se questo parametro è selezionato, il primo colore sarà lo sfondo dell'uovo. Il secondo colore saranno i cerchi sull'uovo.

Puoi anche scegliere la scheda creativa per l'uovo di spawn.