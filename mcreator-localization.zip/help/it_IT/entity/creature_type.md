Ti permette di impostare il tipo di creatura, causando alcune modifiche.
* **Non Morto** subisce danni extra dall'incantesimo Anatema, sono curati dalle pozioni di Danno e danneggiati da Guarigione, e non sono influenzati da veleno o rigenerazione.
* Gli **artropodi** subiscono danni aggiuntivi dall'incantesimo Flagello degli artropodi.
* **Illager** non sembra avere alcun effetto.
* **Acquatico** subisce danni extra dall'incantesimo Impalamento. 