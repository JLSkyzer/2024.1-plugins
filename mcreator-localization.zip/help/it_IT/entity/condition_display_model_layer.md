Mentre il valore restituito è vero, il livello del modello è visibile.
