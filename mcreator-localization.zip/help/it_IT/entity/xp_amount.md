Questo parametro controlla la quantità di esperienza guadagnata uccidendo il mob.

Questo parametro è solitamente 1-3 per un animale e 5 per un mostro.