Aggiungi delle variabili personalizzate alla tua entità personalizzata.

Queste variabili sono sincronizzate tra lato client e lato server,
in modo che uno di loro possa essere utilizzato, per esempio, per cambiare la texture della tua entità.
