Questo parametro controlla il tipo di generazione per i biomi i cui mob sono definiti per generare.

* Un mob contrassegnato come Mostro genererà solo al buio o di notte.
* Un mob contrassegnato come Creatura genererà sotto la luce solare diretta solo su blocchi di materiale erboso. Non utilizzare questo tipo di spawn con entità viventi di tipo mob in quanto non genereranno
* Un mob contrassegnato come Ambientale genererà in qualsiasi condizione tranne se il tipo di blocco lo impedisce, ma questa categoria dovrebbe essere usata per i mob senza alcun effetto di gameplay come i pipistrelli
* Creatura Aquatica genererà il mob in acqua, ma senza altre limitazioni

Il sistema del tipo di Spawn è spiegato in dettaglio [qui](https://mcreator.net/wiki/mob-spawning-parameters)