Questo è il valore predefinito della variabile dell'entità.

- **Logica**: _vero_ o _falso_
- **Numero**: Può passare dal limite massimo negativo al limite massimo positivo di un numero intero
- **Stringa**: Valore testo/stringa
