I livelli del modello nella lista sottostante saranno applicati in cima al modello dell'entità.
