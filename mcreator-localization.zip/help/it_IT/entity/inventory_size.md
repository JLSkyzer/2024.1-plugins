Questo parametro controlla quanti slot utilizzerà il tua entità per il suo inventario interno.

Imposta questo valore su `l'ID slot più grande nella GUI + 1`.