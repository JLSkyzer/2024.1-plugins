Un'entità vivente impostata su Mob sarà in grado di attaccare, mentre un'entità vivente impostata su Creatura sarà passiva.

Questo parametro viene sovrascritto dalla base AI quando utilizzato.

Tieni presente che se selezioni il tipo di creatura qui, i tipi di intelligenza artificiale di attacco faranno sì che l'entità blocchi il gioco nella maggior parte dei casi.