Selezionare questo parametro renderà questa entità un'entità volante.

Questo significa che ha un pathfinding per il volo, un regolatore di movimento e avrà gravità e danno di caduta disabilitati.