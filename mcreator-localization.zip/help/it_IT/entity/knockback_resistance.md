La resistenza al contraccolpo definisce la resistenza all'attacco al contraccolpo dell'entità. In generale, la maggior parte delle entità vanilla non lo usa, ma come riferimento il Ravager ha 0.5.
