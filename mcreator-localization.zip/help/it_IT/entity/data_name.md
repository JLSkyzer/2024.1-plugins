Questo parametro definisce il nome di questa variabile.

Utilizzato principalmente con blocchi di procedure per ottenere o impostare il suo valore.
