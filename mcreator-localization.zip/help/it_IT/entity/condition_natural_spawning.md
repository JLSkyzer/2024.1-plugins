Per generare la tua entità come quelle vanilla, non è necessario modificare questa opzione.

Tuttavia, se desideri avere condizioni di generazione personalizzate, devi creare una nuova procedura di condizione.