Il minimo e il massimo specificato qui impostano la dimensione dei gruppi in cui l'entità genererà.

Tenete a mente che le entità faticano a generarsi in gruppi di oltre 20 (dato che i gruppi genereranno più raramente).