Aggiungere un AI vanilla creearà un'entità dal comportamento del gioco di base.

Questo sovrascriverà alcuni parametri come i drop.

Di solito questo parametro dovrebbe essere evitato e lasciato predefinito.