Questo parametro controlla fino a quanti blocchi l'entità è tracciata dai giocatori.

Impostare questo parametro a 0 disabiliterà completamente il rendering e le collisioni dell'entità.