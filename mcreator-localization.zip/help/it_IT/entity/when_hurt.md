Questo trigger avvia la procedura quando l'entità viene danneggiata.

`entità sorgente`la dipendenza in questo caso è l'entità che causa il danno a tale entità e può essere nulla se il danno è causato da una fonte non entità.

Se la procedura restituisce un valore logico `falso`, l'entità non riceverà alcun danno.
