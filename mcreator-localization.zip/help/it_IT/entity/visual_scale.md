Questa funzionalità ti permette di controllare la dimensione del modello visito dell'entità' nel gioco.

Per ridimensionare la casella di collisione dell'entità, utilizzare il parametro 'Bounding box scale'.
