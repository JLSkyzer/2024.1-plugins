Se selezionato, questo attiverà le attività AI per l'entità.

Le attività AI definite nel costruttore di attività AI non avranno effetto a meno che non sia abilitato.

A meno che tu non stia creando una sorta di entità diversa, dovresti lasciare questa opzione abilitata.