Se selezionato, la tua entità attaccherà con un proiettile (simile allo scheletro). Puoi selezionare:
* Il tuo proiettile dalla lista (o usare la freccia predefinita);
* Intervallo tra gli attacchi (in tick);
* Il raggio in cui l'entità continuerà a prendere di mira un'altra entità dopo che quell'entità avrà lasciato il suo raggio d'azione.