Questo parametro controlla la dimensione massima dello stack di item che può essere posizionata negli slot di inventario interno dell'entità.

Tieni presente che il numero più piccolo tra questo parametro e la dimensione massima dello stack di articoli determina la dimensione massima effettiva dello stack.