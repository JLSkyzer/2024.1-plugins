Questo parametro consente al giocatore di cavalcare questa entità.

È possibile abilitare anche i controlli opzionali.