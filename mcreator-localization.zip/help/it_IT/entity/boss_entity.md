Se selezionata la tua entità sarà un boss.

Il parametro colore controlla il colore della barra dei boss, simile allo stile della barra.