Il suono vivente è il suono ambientale che l'entità riprodurrà in modo casuale.

Lascia vuoto per disattivare il suo suono ambientale.