Selezionando questo parametro si rende l'entità un'entità acquatica.

Abilitando questo parametro l'entità avrà un navigatore di tipo acquatico, un regolatore di movimento nell'acqua e permetterà al generatore mondiale di generarla nei fluidi.

Questo non farà generare l'entità nei fluidi.