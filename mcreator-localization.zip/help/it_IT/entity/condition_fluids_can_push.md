Quando questa condizione è falsa, l'entità non sarà spinta dai fluidi. Dovresti abilitarla durante la creazione di un'entità acquatica.

Il valore predefinito per le entità viventi è vero.