Questa opzione controlla il tipo di questa variabile di entità. I tipi supportati sono le variabili logica, numerica e stringa.
