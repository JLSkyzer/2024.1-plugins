Se questa funzione è abilitata, la casella di delimitazione dell'entità agirà come la casella di delimitazione di un blocco (collisione solida).

Utilizzato da barche e shulkers in Minecraft vanilla.