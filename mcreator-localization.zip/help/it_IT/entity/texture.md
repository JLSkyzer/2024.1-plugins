La texture della tua entità. Assicurati che sia compatibile con il modello selezionato.

I modelli bipedi, ad esempio, supportano solo texture di tipo bipede 64x64 (64x32 prima di Minecraft 1.18).

Per una definizione più complessa dei livelli di un modello, usa la scheda "${l10n.t("elementgui.living_entity.page_model_layers")}".