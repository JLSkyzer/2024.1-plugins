Questa funzionalità ti consente di controllare le dimensioni della scatola di collisione della tua entità.

Per ridimensionare l'aspetto delle entità nel gioco, utilizzare il parametro "Model visual scale".
