Se selezionato, questo mob despawnerà dal giocatore che si muove abbastanza lontano (comportamento predefinito per la maggior parte dei mob).

Disattivare questo per boss e mob evocabili per fermare il despawn.