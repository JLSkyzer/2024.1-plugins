Imposta l'altezza del passo dell'entità.

La maggior parte delle entità viventi normali hanno un'altezza del passo di 0,6, mentre le entità cavalcabili come i cavalli hanno un'altezza del passo di 1.