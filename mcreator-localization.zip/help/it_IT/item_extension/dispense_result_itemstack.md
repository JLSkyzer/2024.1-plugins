Questa procedura determina cosa succede all'oggetto dopo aver tentato di essere distribuito. Se non è selezionato niente o la procedura selezionata non restituisce itemstack, lo stack di elementi corrente utilizzato per l'erogazione verrà ridotto di 1 in caso di erogazione riuscita.

Puoi utilizzare questa procedura per consumare l'oggetto, danneggiarlo o sostituirlo con un altro oggetto.