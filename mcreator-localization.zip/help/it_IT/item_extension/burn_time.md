Burn Time indica quanti tick un dato carburante durerà.

Il carbone impiega 80 secondi per bruciare completamente via e quindi è 1600 tick. (Impostazione predefinita) Questo è sufficiente per cuocere 8 elementi. Ciò significa che 20 tick sono 1 secondo di tempo.

Per misurare quanti tick devi utilizzare, usa questa equazione:

`# di tick necessari = # di oggetti che vuoi che il carburante cucini* 200`

Fai clic [qui](https://mcreator.net/wiki/burn-time-fuels) per un elenco dei tempi di combustione degli oggetti comunemente utilizzati per la fusione in Minecraft.

