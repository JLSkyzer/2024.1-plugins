Questa condizione determina se l'erogazione è completa. Se la condizione fallisce, il dispenser riprodurrà l'effetto di fallimento.

Il valore di questa procedura viene passato a "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}" come dipendenza dal "successo".