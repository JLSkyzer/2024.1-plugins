Questo numero rappresenta la percentuale di possibilità dell'oggetto di aggiungere uno strato al blocco del composter. Mantieni il valore 0 per disabilitarlo.

I valori vanilla possono essere trovati [qui](https://minecraft.wiki/w/Composter#Composting).