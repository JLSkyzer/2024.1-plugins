Il blocco usato come blocco di lavoro dai villici di questa professione.

Se due mod definiscono lo stesso blocco di professione, o un'altra mod usa POI con questo blocco per qualche altra funzione, la professione non funzionerà. Per questo motivo, si raccomanda di controllare due volte che il blocco utilizzato sia unico.