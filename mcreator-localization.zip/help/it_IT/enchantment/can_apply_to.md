Specifica qui gli oggetti che possono ricevere l'incantesimo (o non se in modalità esclusione) nel tavolo da incantamento.

Puoi anche aggiungere oggetti che non sono nel tipo di incantesimo che hai definito.

Nella maggior parte dei casi vorresti mantenere questo vuoto (viene utilizzata la logica di rilevamento della compatibilità vanilla).

**Includi** permetterà agli elementi selezionati di ricevere questo incantesimo. **Escludi** non permetterà agli elementi selezionati di ricevere questo incantesimo
