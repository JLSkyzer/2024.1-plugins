Gli incantesimi con questa proprietà sono cattivi (il loro nome è rosso).

MALEDIZIONE DELLA SCOMPARSA e MALEDIZIONE DEL LEGAME hanno questo proprietà.

Gli incantesimi maledizione non possono essere rimossi dagli oggetti.