Determina la compatibilità con altri incantesimi specifici.

Lascia questo vuoto per permettere la combinazione con qualsiasi incantesimo.

**Includi** renderà gli incantesimi selezionati compatibili. **Escludi** renderà gli incantesimi selezionati incompatibili.