Un incantesimo del tesoro non può essere ottenuto dal tavolo da incantamento.

Può essere trovato solo nelle loot table, come RIPRISTINO o il più recente VELOCITÁ DELLE ANIME.