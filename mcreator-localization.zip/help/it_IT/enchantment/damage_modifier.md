Questo valore verrà moltiplicato per il livello dell'incantesimo (che l'oggetto possiede attualmente) per ottenere il numero di danni che il tuo incantesimo proteggerà.

Ad esempio, PROTEZIONE ha valore 1, quindi per il primo livello l'incantesimo lo farà proteggi il giocatore da 1 danno come 1 (livello) * 1 (il tuo valore) = 1.