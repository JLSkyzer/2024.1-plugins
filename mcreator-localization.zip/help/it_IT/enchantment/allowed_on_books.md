Seleziona questa opzione per abilitare un libro incantato per il tuo incantesimo.

Non puoi definire la scheda creativa, poiché è definita dal tipo di incantesimo che hai definito all'inizio.