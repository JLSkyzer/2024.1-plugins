Seleziona il modello da utilizzare con questo oggetto. Il modello definisce solo l'aspetto visivo.

* **Normale** - Item normale
* Strumento: modello utilizzato dagli strumenti
* Personalizzato: puoi definire anche modelli JSON e OBJ personalizzati

Quando si creano modelli personalizzati, si consiglia il JSON a causa del supporto Vanilla per questo tipo di modello.