La procedura viene eseguita quando un giocatore fa clic con il pulsante destro del mouse con questo item in mano.

Se vuoi che questa procedura venga chiamata solo quando l'entità fa clic con il pulsante destro del mouse in aria con questo oggetto, La procedura "${l10n.t("elementgui.common.event_right_clicked_block")}" dovrebbe sempre restituire SUCCESSO/CONSUME.