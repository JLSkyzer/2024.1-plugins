Questo parametro aggiunge un suggerimento all'item quando tieni la tua icona sopra di esso nel tuo inventario.

Se utilizzi una descrizione generata da una procedura e il tuo item non è impugnato da un'entità o attualmente un'entità item per terra, la dipendenza `entità` sarà nulla.