Attiva una procedura quando l'entità utilizza l'item in aria.

Ad esempio, se fai clic con il tasto destro del mouse sul tuo item in aria, la procedura verrà eseguita.