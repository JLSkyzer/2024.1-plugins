Questo è il tipo di proiettile che questo oggetto a distanza può sparare.

Puoi creare e utilizzare un proiettile personalizzato o utilizzarne uno vanilla Se selezioni un proiettile vanilla, i suoi valori avranno una priorità più alta rispetto ai valori specificati qui.