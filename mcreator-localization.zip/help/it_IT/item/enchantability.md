Come gli incantesimi rari comuni possono essere incantati su questo oggetto/strumento. Maggiore è l'incantevolezza, migliori saranno gli incantesimi che otterrai quando incanterai l'oggetto/strumento.

Valori vanilla:

* Utensili in legno: 15
* Utensili in Pietra: 5
* Utensili in Ferro: 14
* Utensili d'oro: 22
* Strumenti in diamante: 10
* Strumenti in netherite: 15
* Libri: 1