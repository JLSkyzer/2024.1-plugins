Abilitando questo parametro, diventerà un oggetto a distanza che gli permetterà di sparare un proiettile, come archi e balestre.

Per permettere a oggetti a distanza di lavorare, imposta l'animazione su arco o simile e assicurati di usare un valore diverso da zero per la durata di utilizzo dell'elemento.

Se usi la funzione per oggetto a distanza, l'oggetto sparerà solo se l'oggetto richiesto (munizioni) è nell'inventario del giocatore. Queste sono freccie quando si utilizzano frecce vanilla o l'oggetto specificato nel parametro dell'oggetto richiesto di un proiettile personalizzato.

Se si desidera sparare a un proiettile senza il sistema d'oggetto richiesto, utilizzare il trigger del pulsante destro del mouse della procedura e le procedure per sparare esso.