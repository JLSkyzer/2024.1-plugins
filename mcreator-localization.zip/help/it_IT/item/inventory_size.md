Seleziona il numero di slot di cui dispone la tua GUI/inventario. Non dimenticare di aggiungere 1 all'ID dello slot più grande.

Se il blocco è associato alla GUI, imposta questo valore su `l'ID slot più grande nella GUI + 1`