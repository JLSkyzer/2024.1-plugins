Seleziona la tua GUI qui per abilitare l'inventario e l'associazione GUI su questo item.

Imposta su Vuoto per disabilitare l'inventario (probabilmente vorrai questo nella maggior parte dei casi).

L'abilitazione dell'inventario renderà questo oggetto non impilabile.