Questo parametro controlla per quanto tempo l'item può essere utilizzato in una sola volta.

Se l'item è un cibo, questo valore definirà il tempo in tick che il giocatore necessiterà per mangiarlo.