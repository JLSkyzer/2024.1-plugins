Questo parametro controlla il nome di questa proprietà. Non sono ammessi nomi duplicati.

Esistono alcune proprietà definite per tutti gli item per conto di Minecraft vanilla, quindi i loro nomi non possono essere utilizzati.