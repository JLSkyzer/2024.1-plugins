Questa procedura verrà attivata prima che l'oggetto a distanza venga utilizzato per verificare se il valore restituito dalla procedura selezionata è vero.

Mantieni "${l10n.t("condition.common.true")}" per disabilitare eventuali condizioni aggiuntive. In questo caso si applicano ancora i controlli sulle munizioni.