Questa procedura viene utilizzata quando il giocatore smette di usare (rilascia il tasto destro) questo item.

Questo trigger funziona solo se la durata di utilizzo dell'item è superiore a 0.