Questo è il numero massimo di item di questo tipo che possono essere inseriti in una pila.

Esempio vanilla: le perle dell'End hanno una dimensione stack di 16.