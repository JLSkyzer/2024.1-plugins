Questo parametro controlla la dimensione massima della pila che può essere posizionata nei suoi slot di inventario interni.

Tieni presente che il numero più piccolo tra questo parametro e la dimensione massima dello stack di articoli determina la dimensione massima effettiva dello stack.