Il parametro controlla la velocità con cui questo oggetto distrugge i blocchi.

Valori tipici:
* **1** - oggetto normale
* **1.5** spada
* **2>** strumento di raccolta