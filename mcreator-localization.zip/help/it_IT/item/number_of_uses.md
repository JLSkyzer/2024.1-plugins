Questo parametro controlla la durabilità dell'item (quante volte può essere utilizzato).

Imposta questo valore su 0 per disabilitare l'uso della meccanica di conteggio sull'oggetto specificato.

Valori vanilla per riferimento:

* Oro: 32 usi
* Legno: 59 usi
* Pietra: 131 usi
* Ferro: 250 usi.
* Diamante: 1561 usi
* Netherite: 2031 usi
* Canna da pesca: 64 usi
* Acciarino: 64 usi
* Bastone con carota: 25 usi
* Cesoie: 238 usi
* Tridente: 250 usi
* Balestra: 326 usi
* Scudo: 336 usi
* Arco: 384 usi
* Elytra: 432 usi