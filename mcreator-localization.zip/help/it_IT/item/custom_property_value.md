Specifica una procedura per determinare il valore della proprietà personalizzata di questo item.

Se un'entità detiene questo item, le coordinate/il mondo forniti descrivono la posizione di tale entità.