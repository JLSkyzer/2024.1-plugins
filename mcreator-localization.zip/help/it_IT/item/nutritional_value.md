Il valore nutrizionale è quanto questo cibo alimenta il giocatore.

1 è 1/2 della barra del cibo. 20 è l'intera barra del cibo.