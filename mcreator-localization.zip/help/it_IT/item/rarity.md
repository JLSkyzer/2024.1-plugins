La rarità influisce solo sul colore del nome dell'oggetto.
* Comune: bianco
* Non comune: giallo
* Raro: acqua
* Epico: viola chiaro