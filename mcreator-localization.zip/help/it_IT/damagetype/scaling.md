Questo parametro determina se il danno inflitto dovrebbe aumentare con la difficoltà.

- `never`: la difficoltà non influisce sul danno inflitto
- `always`: la difficoltà aumenta sempre il danno inflitto, indipendentemente dalla sorgente
- `when_caused_by_living_non_player`: la difficoltà aumenta il danno inflitto solo se è causato da un'entità vivente
  (come zombie o ragni)
