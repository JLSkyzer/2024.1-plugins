Questo messaggio viene visualizzato in chat quando un giocatore viene ucciso da un entità con un elemento nominato.

È possibile utilizzare i seguenti token nel messaggio:

- `<player>`: il nome del giocatore che è morto
- `<attacker>`: il nome dell'entità che ha inflitto il danno
- `<item>`: il nome dell'oggetto tenuto dall'attaccante
