Questo parametro determina quali suoni devono essere riprodotti quando si ricevono danni di questo tipo
