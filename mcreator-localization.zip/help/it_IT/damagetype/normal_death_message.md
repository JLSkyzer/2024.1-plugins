Questo messaggio viene visualizzato in chat quando un giocatore muore per danni di questo tipo, nella maggior parte delle situazioni.

È possibile utilizzare i seguenti token nel messaggio:

- `<player>`: il nome del giocatore che è morto
- `<attacker>`: il nome dell'entità' che ha inflitto il danno

NOTA: Utilizza il secondo token solo se il danno è sempre causato da un mob.
