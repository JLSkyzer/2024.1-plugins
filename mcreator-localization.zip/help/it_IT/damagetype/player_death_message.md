Questo messaggio viene visualizzato in chat quando un giocatore muore per danni di questo tipo, ma recentemente è stato ferito da un altra entità.

È possibile utilizzare i seguenti token nel messaggio:

- `<player>`: il nome del giocatore che è morto
- `<attacker>`: il nome dell'entità che ha inflitto il danno
