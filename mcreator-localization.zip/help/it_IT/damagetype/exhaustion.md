Questo parametro determina quando esaurimento viene applicato al giocatore quando il danno viene inflitto.

Valori più elevati riducono la barra della fame più velocemente.
