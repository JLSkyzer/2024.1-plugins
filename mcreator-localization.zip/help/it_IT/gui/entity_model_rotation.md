Il parametro di rotazione dell'imbardata dell'entità definisce la rotazione iniziale del modello dell'entità renderizzato in gradi.

Valori più grandi possono causare alcuni problemi di rendering a causa delle limitazioni del motore di rendering.