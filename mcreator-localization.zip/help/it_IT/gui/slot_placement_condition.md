Se la condizione ritorna vera, i giocatori non saranno in grado di posizionare gli oggetti all'interno di questo slot. Tuttavia, saranno ancora in grado di prendere articoli senza alcuna restrizione.

Nota: Questa condizione sovrascrive il parametro "Limit stack input".