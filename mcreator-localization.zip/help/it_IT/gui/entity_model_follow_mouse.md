Se selezionato, il modello di entità visualizzato ruoterà verso la posizione del mouse.

La rotazione del mouse verrà aggiunta al valore di rotazione fisso esistente.