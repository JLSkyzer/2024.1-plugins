Controlla questo parametro nel caso in cui il tuo effetto sia dannoso per il giocatore.

Esempio: il Veleno o il Danno Istantaneo.