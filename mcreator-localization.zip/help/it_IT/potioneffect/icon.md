Questo parametro controlla l'icona visualizzata all'interno dell'inventario del giocatore quando la pozione è attiva.

IMPORTANTE: Se il nome della texture differisce dal nome del registro dell'elemento, verrà creata una copia della stessa texture.