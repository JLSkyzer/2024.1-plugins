Selezionare il colore delle bottiglie e per la freccia.

Non hai bisogno di questa opzione se non vuoi gli item.