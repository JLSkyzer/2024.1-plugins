Controlla questo parametro nel caso in cui il tuo effetto sia benefico per il giocatore

Esempio: Rigenerazione o salute istantanea.