Questa condizione determina se l'effetto deve attivare la sua procedura di tick, in base al livello e alla durata rimasta.

Usa questa condizione per creare effetti che si comportano come rigenerazione o veleno. Un modello di procedura per questo è disponibile.