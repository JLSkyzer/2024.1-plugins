L'icona per identificare la scheda creativa come la polvere di pietrarossa per la scheda della pietrarossa.

Qui sono supportati solo gli items. I blocchi senza item non possono essere visualizzati come icona.