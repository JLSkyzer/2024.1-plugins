La trama dell'item che rappresenta il proiettile. Apparirà identico a ciò che hai selezionato qui.

Per le forme personalizzate, utilizzare il parametro per i modelli.