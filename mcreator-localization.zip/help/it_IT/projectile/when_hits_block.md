Quando il proiettile colpisce un blocco, eseguirà la procedura selezionata.

x, y, e z sono le coordinate del blocco colpito.