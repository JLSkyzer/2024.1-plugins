Quando il proiettile colpisce un giocatore eseguirà la procedura selezionata.

Tieni a mente che questa procedura si potrebbe anche attivare quando il proiettile colpisce l'entità lo ha sparato.