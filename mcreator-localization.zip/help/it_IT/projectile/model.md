Il modello proiettile è il modello del tuo oggetto a distanza.

Questo parametro sovrascriverà l'item per utilizzato la texture.