Seleziona questo parametro se vuoi che venga acceso un fuoco quando il proiettile colpisce un blocco.

NOTA: non darà fuoco ai mob