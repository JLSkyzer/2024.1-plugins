L'icona mostrata nella scheda Avanzamenti.

Se questo è un genitore root allora sarà anche l'icona di avanzamento.

Qui sono supportati solo gli items. I blocchi senza item non possono essere visualizzati come icona.