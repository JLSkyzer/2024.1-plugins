Questo è il tipo di risultato

* Il compito è un tipo di risultato di base ed è più comune.
* L'obiettivo è un obiettivo a lungo termine che si cerca di raggiungere.
* L'intento della Sfida è quello di testare le capacità di un giocatore o sfidarli a qualcosa.