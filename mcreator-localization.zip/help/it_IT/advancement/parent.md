Questo è il progresso dopo il quale il vostro risultato sarà elencato.

Usare "Nessun genitore: radice" creerà un nuovo percorso (nuova scheda di avanzamento).