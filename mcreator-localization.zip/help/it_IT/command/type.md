Questa opzione ti permette di determinare il tipo del comando e come/dove può essere usato.

* **STANDARD**: Il comando può essere usato d'appertutto. Questa è il comune/normale comportamento (e.g. `/give`).
* **SOLO_GIOCATORE_SINGOLO**: Il comando è disponibile solo in mondi in giocatore singolo (e.g. `/publish`).
* **SOLO_MULTIGIOCATORE**: Il comando sarà disponibile solo sui server multiplayer (e.g. `/ban`).
* **LATO_CLIENT**: Il comando sarà esclusivamente sul lato client, significando che solo azioni sul client possono essere eseguite.