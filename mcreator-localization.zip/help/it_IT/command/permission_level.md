Il giocatore dovrà avere almeno questo livello di autorizzazione per eseguire il comando.

Puoi anche disabilitare il requisito dell'autorizzazione. In questo caso, il comando funzionerà anche se i trucchi in un dato mondo sono disattivati.

1 è il livello di autorizzazione più elementare e 4 è il livello più alto (livello OP del server).

Controlla [questa pagina](https://mcreator.net/wiki/command-permission-levels) per vedere quale comando può essere eseguito con ciascun livello di autorizzazione.