Questo parametro controlla quanto è rara o comune la struttura per 1.000.000 di blocchi.

L'impostazione di questo valore a cifre troppo alte potrebbe causare un rallentamento della generazione del mondo o addirittura arresti anomali del gioco.