Usa questo campo per definire i biomi dove dovrebbe avvenire la generazione.

L'elenco non può essere vuoto in quanto le strutture devono definire esplicitamente i biomi a cui sono applicate.