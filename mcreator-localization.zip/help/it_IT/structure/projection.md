Questo parametro controlla come la struttura si adatta al terreno.

Usa terrain_matching se vuoi che la struttura corrisponda al terreno, come fanno i sentieri del villaggio. Questo sposterà l'altezza della struttura su alcune parti.

Rigid posizionerà la struttura piatta così com'è.