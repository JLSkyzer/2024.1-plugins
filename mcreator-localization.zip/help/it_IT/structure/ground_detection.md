Questo parametro controlla come verrà rilevato il terreno per il posizionamento della struttura.

Esempio: Se realizziamo una struttura per un bioma a base di acqua, il blocco **blocco per il movimento** genererà la struttura sotto l'acqua in quanto l'acqua non è considerata un blocco solido dato che le entità possono attraversarlo.

Il tipo di rilevamento **primo blocco** genererà la struttura sopra l'acqua.