Aggiungi le tue condizioni di generazione per generare o meno la struttura.

Verranno controllate anche le condizioni esistenti come le limitazioni del bioma e dei blocchi.

La struttura genererà solo se la procedura di condizione restituisce true.

Tieni presente che alcune procedure potrebbero non funzionare correttamente in questo trigger durante la prima generazione del mondo.