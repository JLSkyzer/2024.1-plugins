Il limite attuale di Vanilla per una singola struttura è di 48x48x48 blocchi per motivi di prestazioni.

Il blocco struttura è un blocco vanilla integrato che può salvare le build come strutture .NBT.

È possibile utilizzare i vuoti strutturali per consentire alla struttura di consentire ad altri blocchi di sovrascrivere i blocchi di tipo aria nella struttura quando viene generato. Se ad esempio vuoi che la tua struttura sia interrata all'interno puoi riempire all'interno della struttura con vuoti strutturali utilizzando il comando /fill per consentire ai blocchi naturali di generano dove sono i vuoti. I vuoti non verranno generati nelle tue strutture, sono solo blocchi segnaposto per lasciarne passare altri blocchi sovrascrivono l'area durante la generazione.