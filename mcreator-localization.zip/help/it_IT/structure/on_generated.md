La procedura viene eseguita ogni volta che la struttura viene generata nel mondo.

Tieni presente che alcune procedure potrebbero non funzionare correttamente in questo trigger durante la prima generazione del mondo.