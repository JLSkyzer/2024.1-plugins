Questo parametro controlla:

* quanti blocchi sull'asse X rispetto al punto di spawn iniziale verrà generata la struttura.
* quanti blocchi sopra o sotto il punto di spawn iniziale verrà generata la struttura.
* quanti blocchi sull'asse Z rispetto al punto di spawn iniziale verrà generata la struttura.