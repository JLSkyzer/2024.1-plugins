Questo parametro controlla come il terreno si adatta alla struttura.

* **none** - Nessun effetto sul terreno.
* **barbeard_thin** - Aggiunge terreno sotto la struttura e lo rimuove dall'interno della struttura. Questa opzione è usata dai villaggi usano.
* **barbeard_box** - Versione più forte della barbeard_thin. Questa opzione è usata dalle città antiche.
* **bury** - Aggiunge terreno completamente intorno alla struttura. Questa opzione è usata dalle roccaforti.