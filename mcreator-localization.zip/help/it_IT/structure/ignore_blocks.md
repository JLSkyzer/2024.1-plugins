Questa opzione specificherà quali blocchi non posizionare (ignorare) durante la generazione della struttura.

Seleziona l'aria qui per non posizionare blocchi d'aria nella tua struttura. Questo renderà la struttura meglio integrata con l'ambiente, ma in caso di strutture basate su caverne, probabilmente vorrai posizionare anche l'aria.