La procedura verrà eseguita quando un giocatore lascia la dimensione.
