Seleziona questo parametro per utilizzare l'accenditore integrato. Deseleziona questa opzione se prevedi di utilizzare invece un accenditore personalizzato.

Per creare un accenditore personalizzato, crea una nuova procedura e utilizza il modello integrato "Crea portale per una dimensione utilizzando l'elemento accenditore personalizzato".