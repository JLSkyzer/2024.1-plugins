Seleziona questo parametro per abilitare il portale come quello per il Nether per questa dimensione.

È possibile lasciare questa opzione disabilitata e utilizzare le procedure per definire in modo personalizzato come entrare in questa dimensione.