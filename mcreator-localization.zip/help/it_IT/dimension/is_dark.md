Se questo parametro è selezionato, la sorgente di luce globale è disabilitata e la dimensione sarà scura.

Anche se la luce del cielo è disabilitata, questa dimensione non avrà alcuna fonte di luce naturale.

Mantieni il lucernario abilitato per le dimensioni inferiori in tutti i casi, a meno che la dimensione non debba essere completamente buia.