Elenco dei biomi da generare in questa dimensione. I biomi definiscono tutte le caratteristiche per la dimensione come tipi di piante, alberi, strutture e proprietà di spawn.

La dimensione distribuirà uniformemente i biomi in base alle loro proprietà.