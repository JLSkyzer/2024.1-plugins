Questo parametro farà sì che la dimensione abbia un lucernario in modo simile all'overworld con ciclo giorno-notte.

Tieni presente che la luce proveniente dal cielo non si propaga attraverso i blocchi, quindi le dimensioni inferiori con lucernario lo faranno essere ancora buio e necessitare di una fonte di luce globale abilitata per non essere buio.