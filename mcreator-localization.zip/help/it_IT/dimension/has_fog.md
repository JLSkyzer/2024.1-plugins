Seleziona questo parametro per abilitare la nebbia densa nella dimensione, anche se il rendering la distanza è impostata su valori grandi. Un esempio di ciò può essere visto nel Nether.
