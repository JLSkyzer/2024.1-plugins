Seleziona questa opzione per abilitare lo stoccaggio di energia.

I blocchi devono avere l'entità blocco abilitata affinché il sistema energetico funzioni correttamente.