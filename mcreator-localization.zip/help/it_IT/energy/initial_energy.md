Imposta il valore predefinito dell'elemento energia (blocco, elemento, ...).

Questa è l'energia che il tuo elemento avrà quando un giocatore lo posiziona nel mondo, l'elemento viene naturalmente generato o altrimenti appare nel mondo).