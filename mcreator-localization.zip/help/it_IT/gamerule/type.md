Questo è il tipo di regola di gioco. Devi selezionare il tipo migliore in base a ciò vuoi fare
* Numero significa che la regola di gioco può essere modificata solo per essere un numero (intero)
* Logica significa che la regola del gioco può essere solo un booleano (vero o falso)