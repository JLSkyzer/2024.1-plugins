Questo parametro controlla con quale strumento si desidera estrarre il blocco.

I minerali usano il piccone, l'ascia i tronchi, la terra la pala.

Se impostato su "Non specificato", i giocatori potranno rompere questo blocco con la mano.
