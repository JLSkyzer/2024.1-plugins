Questa condizione determina se l'uso della farina d'ossa su questo blocco ha successo.

Se questo restituisce falso, la farina di ossa verrà consumata, ma il La procedura "${l10n.t("elementgui.common.event_on_bonemeal_success")}" non verrà eseguita.