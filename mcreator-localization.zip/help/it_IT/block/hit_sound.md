Questo è il suono riprodotto quando il giocatore estrae il blocco.

NOTA: questo suono viene riprodotto in loop durante la rottura finché il blocco non viene rotto.