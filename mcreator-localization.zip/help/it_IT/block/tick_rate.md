Questo parametro controlla la frequenza con cui il blocco eseguirà un tick. Se viene selezionato l'opzione per abilitare i tick in modo casuale, questo parametro non ha alcun effetto.

Tenete a mente che di solito i blocchi generati naturalmente eseguiranno tick per impostazione predefinita, a meno che non sia stato impostato il tick casuale.

Il tasso di tick predefinito a 0 significa che il blocco non eseguirà alcun tick automaticamente.

Se questo parametro è impostato a un numero maggiore di 0, il blocco eseguirà un tick automaticamente. Ci sono 20 tick mondiali in un secondo.