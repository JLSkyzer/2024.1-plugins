Seleziona questo parametro se il tuo blocco:

* non è un solido cubo / ha una forma personalizzata,
* ha parti trasparenti nella texture.

Se si seleziona questa casella, il blocco sarà:

* non conduttore del il potere della pietrarossa,
* ha l’occlusione disabilitata,
* ha la casella di delimitazione visiva impostata su vuota.