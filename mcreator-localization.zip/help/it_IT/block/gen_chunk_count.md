Imposta il numero medio di vene da generare per chunk.

Valori dei gruppi di minerali per chunk:

* Minerale Di Carbone - 20
* Minerale Di Ferro - 20
* Minerale D'Oro - 2
* Minerale di Pietrarossa - 8
* Minerale di Diamante - 1
* Minerale di Lapislazzuli - 1