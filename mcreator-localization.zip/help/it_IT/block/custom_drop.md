Questo parametro definisce un item personalizzato o un blocco che viene rilasciato quando questo blocco viene estratto/rotto.

Se viene utilizzato il livello di raccolta, solo gli strumenti di livello adeguato faranno droppare il blocco.