Se questo parametro è selezionato, la polvere di pietra rossa si collegherà sempre a questo blocco (simile ai blocchi Redstone).

NOTA: il blocco può comunque emettere energia di pietra rossa anche se questo parametro non è selezionato.