La forma di generazione permette di cambiare il modo in cui il blocco viene generato a seconda dell'altezza del blocco.

* **Uniforme**: Si tratta di un semplice rettangolo. Questa era la forma usata prima di Minecraft 1.18.
* **Triangolo**: Questa forma farà generare il blocco come un triangolo. Il livello con la maggior probabilità di ottenere questo blocco sarà al centro dell'altezza minima e massima. Tenete a mente che le altezze di generazione massime e minime possono essere superiori e inferiori ai limiti del mondo.