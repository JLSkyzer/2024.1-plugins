Questa condizione determina se questo blocco può essere posizionato in una posizione specifica. Se la posizione è non più valida, il blocco sarà distrutto quando riceverà un aggiornamento di blocco.

NOTA: Questa condizione non è controllata durante la generazione del mondo.
