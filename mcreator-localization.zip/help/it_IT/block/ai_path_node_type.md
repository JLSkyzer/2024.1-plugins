Questo parametro controlla il modo in cui il blocco verrà "visto" dai navigatori del percorso AI dei mob.

Diversi tipi di nodi del percorso AI portano a decisioni diverse su come procedere con il movimento e quando vicino al blocco, a seconda del tipo di nodo del percorso AI.