* **Nessuna rotazione:** Orientamento del blocco fisso.
* **Rotazione asse Y (S/W/N/E):** Ruota solo i lati in base al modo in cui il giocatore sta guardando.
* **D/U/N/S/W/E rotazione:** Ruota tutti i lati in base al modo in cui il giocatore sta guardando.
* **Rotazione asse Y (S/W/N/E):** Ruota solo i lati in base alla faccia del blocco su cui viene cliccato il blocco.
* **D/U/N/S/W/E rotazione:** Ruota tutti i lati in base alla faccia del blocco su cui viene cliccato il blocco.
* **Rotazione Tronco (X/Y/Z):** Ruota il blocco come i tronchi vanilla.