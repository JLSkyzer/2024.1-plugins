Questo parametro deve essere utilizzato solo in combinazione con blocchi trasparenti.

Se questa opzione è selezionata, il blocco non mostrerà la consistenza fluida quando è immerso, simile ai blocchi di vetro.