Questo parametro controlla l'intervallo di altezza Y in cui questo blocco può generare.

Valori di altezza generazione vanilla:
* Minerale di carbone - da 0 a 256
* Minerale di rame - da -16 a 112
* Minerale di ferro - da -32 a 256
* Minerale di oro - da -64 a 32
* Minerale di Pietrarossa - da -64 a -32
* Minerale di diamante - da -64 a 16
* Minerale di smeraldo - da -16 a 256
* Lapislazzuli: - -64 a 64