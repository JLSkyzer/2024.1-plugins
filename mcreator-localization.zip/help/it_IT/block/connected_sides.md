Questo parametro deve essere utilizzato solo in combinazione con blocchi trasparenti.

Questo renderà i lati interni del blocco in collegamento simile a come il vetro, il ghiaccio e altri blocchi simili fanno.