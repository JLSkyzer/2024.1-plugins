Se il parametro pietrarossa emessa è selezionato, questo parametro ti permetterà di modificare il potere della pietrarossa emesso.

Quando viene utilizzata una procedura condizionale e restituisce un numero, la potenza della pietrarossa emessa da questo blocco sarà impostata dal numero restituito della procedura.

NOTA: Il blocco può ancora emettere pietrarossa anche se la pietrarossa non si connette ad esso.

ATTENZIONE: Quando si utilizza la procedura del provider di numeri personalizzati, è necessario notificare i blocchi di valore di pietrarossa vicini per registrare la modifica.