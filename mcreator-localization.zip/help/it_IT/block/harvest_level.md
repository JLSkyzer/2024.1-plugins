Questo è il livello di strumento richiesto per rompere questo blocco.

* 0 è legno/oro
* 1 è la pietra
* 2 è la ferro
* 3 è diamante.
* 4 è Netherite

Solo il livello di strumento specificato sarà in grado di rompere il tuo blocco. Puoi definire livelli più grandi anche rispetto a Netherite impostando il livello su 4 o più.

La condizione affinché il blocco lasci cadere gli oggetti in caso di rottura è:

`SE LIVELLO DI RACCOLTA DEL BLOCCO <= LIVELLO DI RACCOLTA DELLO STRUMENTO`
