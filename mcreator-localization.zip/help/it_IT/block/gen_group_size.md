Questo parametro controlla la quantità media di blocchi per vena mineraria.

Dimensioni del gruppo di minerale di vanilla:

* Minerale Di Carbone - 17
* Minerale Di Ferro - 9
* Minerale D'Oro - 9
* Minerale di Pietrarossa - 8
* Minerale di Diamante - 8
* Minerale di Lapislazzuli - 7