Se si usa il blocco di base, alcuni parametri potrebbero essere disabilitati o potrebbero non funzionare a causa dei valori predefiniti richiesti da tale blocco di base.

Utilizzare questo parametro solo se esiste una buona ragione per farlo, la maggior parte dei blocchi dovrebbe avere questo selezionato sul blocco base Predefinito.