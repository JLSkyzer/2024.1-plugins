Questo parametro darà un inventario al tuo blocco. Il blocco sarà un'entità blocco.

Questo parametro consente funzionalità come:
* Etichette NBT sul blocco
* Inventario per contenere item nel blocco
* Interazione con il comparatore

Queste funzionalità non funzioneranno senza questo parametro selezionato.