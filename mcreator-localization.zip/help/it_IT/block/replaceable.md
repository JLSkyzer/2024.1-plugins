Se controlli questo parametro, il giocatore sarà in grado di posizionare un altro blocco su di esso (questo blocco può essere sostituito da altri blocchi posizionati).

Esempi: aria, la maggior parte delle piante