Selezionare il colore che il blocco applicherà al fascio del faro (come il vetro rosso, vetro arancione, ecc).

Lasciare a DEFAULT per mantenere la manipolazione vanilla (nessun cambiamento di colore).