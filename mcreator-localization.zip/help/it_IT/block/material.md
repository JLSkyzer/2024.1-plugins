Il materiale del blocco definisce alcune proprietà del blocco base come reazione ai pistoni, all'acqua, alle opzioni di coltivazione delle piante e altro ancora.

Se intendi utilizzare il blocco per ottenere minerale, seleziona il materiale ROCCIA quindi il livello di raccolto viene applicato correttamente.

Fai clic [qui](https://mcreator.net/wiki/materials) per ulteriori informazioni sui materiali.