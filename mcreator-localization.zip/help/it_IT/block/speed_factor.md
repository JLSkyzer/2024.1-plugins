Questo parametro controlla la velocità delle entità su questo blocco.

Il valore predefinito usato dalla maggior parte dei blocchi è 1.0. Il fattore di velocità della sabbia delle anime e dal blocco di miele è 0.4.