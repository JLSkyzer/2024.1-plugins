Elenco di blocchi che questo blocco può sostituire durante la generazione.

Se lasci questa lista vuota, il blocco non genererà naturalmente in quanto non sarà in grado di di posizionarsi sul mondo.