Attiva una procedura quando un'entità cammina sopra questo blocco.

Non verrà chiamato se l'entità sta camminando furtivamente.

Funziona solo con blocchi che hanno piena altezza. Non funzionerà con lastre, piastre di pressione, ecc.

Per questi casi, utilizza invece il trigger di collisione.