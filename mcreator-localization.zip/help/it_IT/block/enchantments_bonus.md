Questo parametro controlla il bonus di potenza che il blocco ha per il tavolo da incantamento.

Il bonus di potenza della libreria è 1, per i blocchi normali è 0.