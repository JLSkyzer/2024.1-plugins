Se questa opzione è selezionata, verrà applicata una tinta fissa al blocco mentre è nell'inventario, corrispondente al tipo di tinta.

La tinta viene applicata anche quando viene specificata una texture per l'item.