Questa condizione determina se la farina d'ossa può essere utilizzata su questo blocco.

Se restituisce falso, la farina di ossa non verrà consumata e non accadrà nulla.