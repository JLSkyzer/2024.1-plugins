Se selezionato, l'acqua sarà posizionabile all'interno del blocco.

Esempi vanilla: Lastre, Scale, ecc.
