Se abilitato, il blocco non genererà automaticamente una loot table. Invece, l'utente dovrà definire manualmente i drop del blocco.

Crea un elemento mod loot table con il nome del registro `blocks/${registryname}`, namespace _mod_e tipo _Block_.

Le tabelle dei bottini possono ancora sovrascrivere i drop del blocco, anche se questa opzione non è abilitata.