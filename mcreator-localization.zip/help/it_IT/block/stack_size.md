Questo è il numero di oggetti che possono essere accumulati negli slot dell'inventario di questo blocco.

Tieni presente che esiste un altro limite di dimensione dello stack di slot impostato per gli elementi specifici, quindi questo è un limite superiore degli slot che possono essere ulteriormente limitati dagli oggetti.