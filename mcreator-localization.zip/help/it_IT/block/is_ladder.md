Se selezionato, le entità saranno in grado di salire sul blocco.

La larghezza e la profondità del blocco devono essere inferiori a 1 perché questo parametro funzioni, così le collisioni nel blocco vengono rilevate correttamente. Modifica le impostazioni del riquadro di delimitazione per abbinarle a questo parametro.

Esempi vanilla: Scala a pioli e Rampicanti