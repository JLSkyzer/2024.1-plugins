Quando un giocatore fa clic con il pulsante destro del mouse sul blocco, la procedura verrà eseguita.

La procedura dovrebbe restituire un risultato dell'azione di tipo SUCCESS/CONSUME se esegue un'azione e PASS altrimenti. Se una GUI viene aperta facendo clic con il pulsante destro del mouse o se la procedura non restituisce alcun valore, il tipo di risultato dell'azione sarà SUCCESS.