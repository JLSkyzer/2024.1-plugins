Selezionare questo parametro se si desidera che gli item cadano quando il blocco è rotto.

I bauli usano questo parametro, per esempio.