Questo parametro definisce se il giocatore sarà in grado di scavarlo.

Esempi Vanilla: Bedrock e blocco comandi