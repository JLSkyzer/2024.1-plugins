Questo parametro controlla se il posizionamento dei blocchi deve essere spostato in modo casuale e da quale asse.

La maggior parte delle piante utilizzano uno dei tipi offset.