Questo parametro controlla quanto è scivoloso il blocco.

Il valore predefinito usato dalla maggior parte dei blocchi è 0.6