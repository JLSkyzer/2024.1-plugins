Seleziona il modello da utilizzare con questo blocco. Il modello definisce solo l'aspetto visivo e non il riquadro di delimitazione del blocco.

* **Normale** - Blocco normale con texture su ciascun lato
* **Singola texture** - Blocco con la stessa texture su tutti i lati
* **Croce** - Modello utilizzato dalle piante
* **Raccolto** - Modello utilizzato dalle piante coltivate
* **Blocco d'erba** - Modello utilizzato dai blocchi d'erba (le texture superiori e laterali verranno colorate)
* Personalizzato: puoi definire anche modelli JSON e OBJ personalizzati

Quando si creano modelli personalizzati, si consigliano i JSON a causa del supporto Vanilla per questo tipo di modello.