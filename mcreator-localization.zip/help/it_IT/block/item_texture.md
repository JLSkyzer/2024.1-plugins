Questa proprietà opzionale cambierà la texture del blocco nell'inventario.

Utilizzato comunemente con porte o modelli personalizzati.