Questo parametro determina come reagisce il blocco con un pistone.

* Normale: reazione normale dei pistoni come la Pietra
* Distruggi: Quando il blocco verrà spinto da un pistone, il blocco verrà distrutto.
* Blocco: il blocco non reagisce a un pistone come l'ossidiana.
* Solo spinta: il blocco può essere spinto solo da un pistone.