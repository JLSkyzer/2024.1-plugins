Se il blocco ha un offset del modello casuale, anche il suo riquadro di delimitazione verrà spostato, a meno che questa opzione non sia selezionata. Se il riquadro di delimitazione si immerge nei blocchi vicini a causa dello spostamento, seleziona questa casella per impedirlo.

Per esempio, questa opzione sarebbe falsa per il bambù, e vero per l'erba alta.