I blocchi generati naturalmente di solito eseguiranno un tick per impostazione predefinita, a meno che non sia usato tick casuale.

Questo parametro rende casuale il tick del blocco, dove la velocità è controllata da un parametro globale di tick del mondo.

Questo tipo di ticking è usato dalle piante, per esempio.