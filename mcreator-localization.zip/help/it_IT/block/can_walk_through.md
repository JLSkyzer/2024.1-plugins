Se questo parametro è selezionato, il giocatore sarà in grado di camminarci attraverso, come erba alta e rampicanti, se lo selezioni.

Il blocco avrà un riquadro di delimitazione, ma non sarà collidibile.