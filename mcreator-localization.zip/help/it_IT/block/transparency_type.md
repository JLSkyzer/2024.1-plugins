**Marca questa casella se il tuo blocco ha trasparenza** - Lascia deselezionato per un blocco solido, controllare se il blocco è simile a foglie, vetro, barre di ferro, ecc.

Tipi di trasparenza:

* **Solido:** Nessuna trasparenza (simile alla terra, pietra, ecc.)
* **Ritagliato:** trasparente senza mipmapping (simile al vetro)
* **Ritagliato mipped:** Like Ritagliato, ma con mipmapping
* **Traslucido:** parzialmente trasparente e l'opzione più ricca di risorse (simile al ghiaccio)