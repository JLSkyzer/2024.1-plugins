Questo parametro determina quanto velocemente il blocco viene consumato dal fuoco.

Esempi vanilla:
* i tronchi hanno un'infiammabilità di 5
* le assi di legno hanno un'infiammabilità di 20