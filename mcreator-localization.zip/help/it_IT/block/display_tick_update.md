Attiva casualmente una procedura.

Questo trigger viene attivato solo sul lato client quindi non devono essere apportate modifiche al mondo reale tranne che per utilizzare suoni e posizionare particelle da qui.