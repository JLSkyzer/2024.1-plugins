Le dimensioni del blocco e il riquadro di delimitazione impostano l'hitbox per il blocco se si tratta di un modello personalizzato. Puoi anche ridimensionare la dimensione di un blocco regolare da qualcosa che è un cubo ad altre dimensioni se non viene utilizzato un modello personalizzato.

Questo imposterà solo le dimensioni, non la forma.

Per capire come funzionano i parametri del riquadro di delimitazione, clicca [qui](https://mcreator.net/wiki/block-dimensions-and-bonding-box).