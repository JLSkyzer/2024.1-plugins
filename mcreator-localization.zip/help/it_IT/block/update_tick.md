Attiva una procedura quando il blocco viene selezionato.

I blocchi generati naturalmente verranno selezionati solo se viene utilizzato il ticchettio casuale per motivi di prestazioni.
