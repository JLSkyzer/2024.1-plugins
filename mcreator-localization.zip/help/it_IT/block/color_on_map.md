Questo è il colore di come il blocco apparirà sulle mappe.

Se impostato su Predefinito, il colore si baserà sul materiale del blocco.

Per vedere gli esatti colori RGB di tutte le voci, leggere la pagina Wiki [qui](https://mcreator.net/wiki/list-block-map-colors).