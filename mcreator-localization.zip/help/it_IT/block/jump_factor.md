Questo parametro controlla l'altezza di salto delle entità

Il valore predefinito usato dalla maggior parte dei blocchi è 1.0. Il fattore dell''altezza del salto del blocco di miele è 0.5.