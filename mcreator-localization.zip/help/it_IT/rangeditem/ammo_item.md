Questo parametro controlla le munizioni usate dall'arma a distanza.

Esempio: la freccia viene usata per l'arco.