Il modello proiettile è il modello del tuo oggetto a distanza.

Questo parametro sovrascriverà l'elemento per il parametro texture quando utilizzato.