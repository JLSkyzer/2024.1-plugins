Seleziona questo parametro se vuoi che accenda un fuoco quando l'oggetto a distanza colpisce un blocco.

NOTA: questo non dà fuoco ai mob