La trama dell'elemento che rappresenta il proiettile. Il proiettile apparirà lo stesso dell'elemento selezionato qui.

Per le forme personalizzate, utilizzare il parametro del modello proiettile.