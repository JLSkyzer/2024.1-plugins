* **Mod:** viene utilizzato solo per la tua mod. (Chiama una funzione come `${modid}:${registryname}`)

* **Minecraft:** viene utilizzato con alcune opzioni di Minecraft (chiama una funzione come `minecraft:${registryname}`)