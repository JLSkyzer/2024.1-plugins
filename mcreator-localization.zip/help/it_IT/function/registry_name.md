Puoi scrivere il nome della funzione in una parola o con più parole con trattini bassi.

Esempi:
* avanzamento
* ricompensa_avanzamento_bioma