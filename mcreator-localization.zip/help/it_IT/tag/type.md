* **Item:** utilizzalo per raggruppare più elementi insieme per ricette, procedure, ... I tag degli item sostituiscono il vecchio sistema dell'Ore Dictionary
* **Blocchi:** usa il tipo di blocco solo se stai cercando un blocco e non il suo item (_questi tag non possono essere usati nelle ricette_)
* **Entità:** usa questo tipo di tag per raggruppare più entità insieme per uno stesso scopo.
* **Funzioni:** questo tipo di tag viene utilizzato per etichettare le funzioni in gruppi. Uno di questi gruppi è chiamato "tick" dallo spazio dei nomi "minecraft". Funzioni etichettate sotto lo spazio dei nomi "tick" verranno eseguito a ogni tick di gioco.
* **Tipo di danni:** questo tipo di tag viene utilizzato per raggruppare insieme i tipi di danni.