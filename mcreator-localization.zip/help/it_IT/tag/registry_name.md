Questo è il nome del registro del tuo tag.

Il testo che scrivi in questo campo è il testo che dovrai scrivere per poter usare il tuo tag.

Quando si estendono gruppi di tag vanilla, usa qui nomi di tag vanilla appropriati e usa lo spazio dei nomi minecraft.