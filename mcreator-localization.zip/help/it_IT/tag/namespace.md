Questo parametro definisce il modo in cui funzionerà il tag.

* **forge:** è un sostituto per l'Ore Dictionary per i tag. Possono essere utilizzati per dare ad altri creatori di mod l'accesso alla loro mod con la tua mod se fornisci loro il nome del tag.
* **c** è uno spazio dei nomi utilizzato dalle mod di Minecraft Fabric per i tag convenzionali (schema standardizzato di denominazione dei tag).
* **minecraft:** è usato per aggiungere blocchi o item personalizzati ai gruppi di tag vaniglia. Ad esempio, aggiungendo i tronchi della tua mod al gruppo di tronchi di Minecraft (impostando il nome ai log e al namespace al minecraft).
* **mod:** è usato per raggruppare gli item nella tua mod per uso interno.