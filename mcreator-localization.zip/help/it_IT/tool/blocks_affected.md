Questo elenco definisce su quali blocchi è possibile utilizzare lo strumento.

Questo parametro viene utilizzato solo dal tipo di utensile speciale.