Lo strumento con un determinato livello di raccolta (livello) può rompere solo blocchi con lo stesso livello o inferiore.

* 0 è legno/oro
* 1 è la pietra
* 2 è il ferro
* 3 è diamante
* 4 è Netherite

Puoi definire livelli più grandi anche rispetto alla Netherite impostando il livello su 5 o più.