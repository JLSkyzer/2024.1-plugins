Questo parametro definisce quanto velocemente lo strumento può scavare.

Esempio: Gli strumenti in pietra hanno un'efficienza inferiore rispetto agli strumenti in diamante.

Valori vanilla:
* Legno: 2.
* Pietra: 4.
* Ferro: 6.
* Diamante: 8.
* Netherite: 9.
* Oro: 12.