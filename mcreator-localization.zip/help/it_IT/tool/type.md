Il tipo di strumento che questo elemento è.

Alcuni dei parametri sottostanti non sono utilizzati da alcuni tipi di strumenti.