Usa questo campo per definire le dimensioni dove dovrebbe avvenire la generazione.

Se l'elenco è vuoto, non verrà impostata alcuna restrizione sulla dimensione e la generazione si verificherà in tutti i biomi.