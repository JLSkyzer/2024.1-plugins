Aggiungere una procedura con valore di ritorno logico per avere più condizioni per la generazione di questa feature.

Questa condizione è controllata DOPO i modificatori di posizionamento nel costruttore di feature.

Tieni presente che alcuni blocchi di procedura potrebbero non funzionare correttamente in questo trigger durante la prima generazione del mondo.