這個數字是該物品添加一層到堆肥桶的概率。 保持數值為0來停用。

原版數值可在<https://zh.minecraft.wiki/w/%E5%A0%86%E8%82%A5%E6%A1%B6?variant=zh-tw#%E5%A0%86%E8%82%A5>此</a>找到