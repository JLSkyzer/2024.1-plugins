如果勾選此項，則發射器不會使用預設操作刪除該物品，而是調用 "${l10n.t("elementgui.item_extension.dispense_success_condition")}" and "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}" 函式
