Tham số này điều khiển biểu tượng được hiển thị trong kho đồ của người chơi khi thuốc đang hoạt động.

QUAN TRỌNG: Nếu tên kết cấu khác với tên đăng kí của mục, một bản sao của kết cấu sẽ được tạo.