Tích tham số này trong trường hợp hiệu ứng của bạn có lợi cho người chơi

Ví dụ: Hồi phục hoặc Hồi máu Tức thì.