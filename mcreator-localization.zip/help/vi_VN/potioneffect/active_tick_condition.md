Điều kiện này xác định liệu hiệu ứng nên kích hoạt quy trình tick của nó, dựa trên cấp độ và thời gian còn lại.

Dùng điều kiện này để tạo các hiệu ứng hoạt động tương tự hồi phục hay độc. Cũng có một mẫu quy trình cho điều này.