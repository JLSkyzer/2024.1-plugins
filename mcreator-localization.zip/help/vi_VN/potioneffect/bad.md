Tích tham số này trong trường hợp hiệu ứng của bạn có hại cho người chơi.

Ví dụ: Thuốc độc hoặc Sát thương Tức thì.