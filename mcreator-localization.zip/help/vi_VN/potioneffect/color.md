Chọn màu cho các lọ thuốc và mũi tên.

Bạn không cần tùy chọn này nếu như bạn không cần các vật phẩm.