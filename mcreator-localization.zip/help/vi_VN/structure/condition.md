Thêm (các) điều kiện khởi tạo của bạn để khởi tạo hoặc không khởi tạo kiến trúc.

Các điều kiện đã có như quần xã và các hạn chế khối cũng sẽ được kiểm tra.

Kiến trúc sẽ chỉ được khởi tạo khi quy trình điều kiện trả về giá trị thỏa mãn.

Lưu ý rằng một vài khối quy trình có thể không hoạt động chính xác trong trình kích hoạt này trong quá trình khởi tạo thể giới sớm.