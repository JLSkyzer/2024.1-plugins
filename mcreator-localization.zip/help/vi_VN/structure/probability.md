Tham số này điều khiển độ hiếm hoặc phổ biến của kiến trúc trên 1,000,000 đoạn khúc.

Đặt giá trị này quá cao có thể khiến thế giới khởi tạo chậm hoặc thậm chí làm quá trình khởi tạo bị sập.