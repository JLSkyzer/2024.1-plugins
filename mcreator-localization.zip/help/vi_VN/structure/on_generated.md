Quy trình được thực thi mỗi lần kiến trúc được khởi tạo trong thế giới.

Lưu ý rằng một vài khối quy trình có thể không hoạt động chính xác trong trình kích hoạt này trong quá trình khởi tạo thể giới sớm.