Tham số này được sử dụng bởi các công thức loại nấu nướng để xác định vật phẩm sẽ nấu trong bao lâu.

Đơn vị là tick, vậy nên để có thời gian nấu là 1 giây, ta cần phải đặt thời gian nấu là 20 tick.