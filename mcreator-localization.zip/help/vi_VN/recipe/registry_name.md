ID công thức của công thức của bạn (Ví dụ: diamond_block).

Nếu bạn muốn ghi đè một công thức vanilla, bạn cần phải nhập tên giống với tên đăng kí vanilla của công thức được cho trong trường này.