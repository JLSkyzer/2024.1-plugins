* Dùng namespace "Mod" để tạo một công thức mới cho mod/gói dữ liệu của bạn.
* Dùng "minecraft" để ghi đè các công thức vanilla.