Tham số này xác định xem hệ thống chế tạo nào mà công thức của bạn sẽ khả dụng.

* Chế tạo là Bàn chế tạo.
* Nung nấu là công thức của Lò nung.
* Luyện kim là công thức dùng trong Lò luyện kim.
* Hun khói là công thức dùng trong Lò hun khói.
* Cắt đá là công thức của Máy cắt đá.
* Nấu nướng bằng lửa trại là công thức khi ta nhấn chuột phải vào Lửa trại.
* Rèn là công thức dùng trong Bàn rèn.
* Pha chế thuốc là công thức dùng trong Giàn pha thuốc.