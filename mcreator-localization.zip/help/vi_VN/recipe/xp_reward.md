Tham số này điều khiển số lượng kinh nghiệm người chơi sẽ nhận được sau khi hoàn thành công thức.

Tham số này chỉ được dùng với các công thức nấu nướng.