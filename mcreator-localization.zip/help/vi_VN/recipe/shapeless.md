Tham số này xác định liệu công thức chế tạo cần phải có một hình dạng cụ thể hay không.

Nếu được tích, bất kỳ bố cục vật phẩm nào với các vật phẩm được cho sẽ được chấp nhận như một công thức.