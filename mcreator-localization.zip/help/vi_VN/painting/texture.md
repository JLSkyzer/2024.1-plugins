Chọn một kết cấu để làm nền chính của bức tranh này.

QUAN TRỌNG: Nếu tên kết câu khác với tên đăng kí của phần tử, một bản sao chép của kết cấu sẽ được tạo.