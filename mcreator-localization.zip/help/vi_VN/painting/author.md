Tham số này xác định tác giả của bức tranh.

LƯU Ý: Bắt buộc, nhưng chỉ được dùng ở 1.19.4+