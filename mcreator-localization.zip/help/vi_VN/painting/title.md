Tham số này xác định tiêu đề của bức tranh.

LƯU Ý: Bắt buộc, nhưng chỉ được dùng ở 1.19.4+