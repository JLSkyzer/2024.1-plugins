Các phù phép với thuộc tính này sẽ trở nên rất tệ (tên của chúng sẽ chuyển đỏ).

LỜI NGUYỀN BIẾN MẤT và LỜI NGUYỀN RÀNG BUỘC có thuộc tính này.

Các phù phép lời nguyền không thể được loại bỏ khỏi vật phẩm.