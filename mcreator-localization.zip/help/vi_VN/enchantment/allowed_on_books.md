Tích tùy chọn này để kích hoạt sách phù phép cho phù phép của bạn.

Bạn không thể xác định tab Sáng tạo, vì nó được xác định bởi loại phù phép bạn chọn ở đầu.