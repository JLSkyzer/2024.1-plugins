Một phù phép kho báu không thể nhận được trong bàn phù phép.

Nó chỉ được tìm thấy trong các bảng loot, chẳng hạn SỬA CHỮA hay là gần đây, TỐC ĐỘ LINH HỒN.