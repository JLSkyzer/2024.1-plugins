Xác định sự tương thích với một số phù phép nhất định.

Để trống để cho phép kết hợp với bất kì phù phép nào.

**Bao gồm** sẽ làm cho các phù phép được chọn tương thích. **Loại trừ** sẽ khiến cho các phù phép được chọn không tương thích.