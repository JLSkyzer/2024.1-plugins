Xác định các vật phẩm có thể nhận được phù phép này (hoặc không nếu ở trong chế độ loại trừ) trong bàn phù phép tại đây.

Bạn cũng có thể thêm các vật phẩm không có trong loại phù phép mà bạn đã chỉ định.

Trong mọi trường hợp bạn muốn để cái này trống (logic phát hiện sự tương thích vanilla được sử dụng).

**Bao gồm** sẽ cho phép các vật phẩm được chọn nhận phù phép này. **Loại trừ** sẽ không cho phép các vật phẩm được chọn nhận phù phép này
