Giá trị này sẽ được nhân lên với cấp độ của phù phép (mà vật phẩm hiện đang có) để lấy được lượng sát thương mà phù phép của bạn sẽ bảo vệ.

Ví dụ, BẢO VỆ có giá trị là 1, nên ở cấp độ thứ nhất, phù phép sẽ bảo vệ người chơi khỏi 1 sát thương là 1 (cấp độ) * 1 (giá trị của bạn) = 1.