* **Không xoay:** Hướng khối cố định.
* **Xoay theo trục Y (S/W/N/E):** Chỉ xoay các bên dựa theo hướng nhìn của người chơi.
* **Xoay theo D/U/N/S/W/E:** Xoay tất cả các mặt dựa theo hướng nhìn của người chơi.
* **Xoay theo trục Y (S/W/N/E):** Chỉ xoay các bên dựa theo hướng khối của khối được nhấn.
* **Xoay theo D/U/N/S/W/E:** Xoay tất cả các mặt dựa theo hướng khối của khối được nhấn.
* **Xoay khúc gỗ (X/Y/Z):** Xoay khối như các khối thân cây vanilla.