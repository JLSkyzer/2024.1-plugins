Tích tham số này nếu khối của bạn:

* không phải là khối rắn / có hình dạng tùy chỉnh,
* hoặc kết cấu có phần trong suốt.

Nếu bạn tích hộp này, khối sẽ:

* không truyền tín hiệu redstone,
* sự nghẽn được vô hiệu hóa,
* hộp đường viền trực quan được đặt thành trống.