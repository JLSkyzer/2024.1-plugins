Điều kiện này xác định liệu khối này có thể được đặt ở một vị trí cụ thể. Nếu tọa độ không còn hợp lệ, khối sẽ bị phá sau khi nhận được cập nhật khối.

LƯU Ý: Điều kiện này không được chọn trong lúc khởi tạo thế giới.
