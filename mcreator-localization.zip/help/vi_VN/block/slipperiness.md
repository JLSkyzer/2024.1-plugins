Tham số này điều khiển độ trơn của khối.

Giá trị mặc định được sử dụng cho hầu hết các khối là 0.6