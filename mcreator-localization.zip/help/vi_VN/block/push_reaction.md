Tham số này xác định cách khối sẽ phản ứng với pít-tông.

* Thường: Phản ứng bình thường với pít-tông giống như Đá
* Phá hủy: Khi khối được đẩy bởi pít-tông, khối đó sẽ bị phá hủy.
* Chặn: Khối không phản ứng với pít-tông giống như Hắc diện hạch.
* Chỉ đẩy: Khối chỉ có thể được đẩy bởi pít-tông.