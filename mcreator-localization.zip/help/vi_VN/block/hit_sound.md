Đây là âm thanh được chơi khi người chơi phá khối.

LƯU Ý: Âm thanh này được lặp lại trong quá trình phá cho đến khi khối bị phá vỡ hoàn toàn.