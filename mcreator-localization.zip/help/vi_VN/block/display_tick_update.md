Kích hoạt một quy trình một cách ngẫu nhiên.

Trình kích hoạt này chỉ được kích hoạt bên máy khách nên sẽ không có thay đổi nào lên thế giới ngoại trừ phát âm thanh và đặt hạt hiệu ứng được thực hiện tại đây.