Tham số này xác định số lượng ô mà khối của bạn sẽ dùng cho kho đồ nội bộ của nó.

Nếu khối được gắn với GUI, đặt giá trị này thành `ID ô lớn nhất trong GUI + 1`