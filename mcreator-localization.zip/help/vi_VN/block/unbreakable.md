Tham số này xác định liệu người chơi có thể phá nó hay không.

Các ví dụ vanilla: Đá nền và khối lệnh