Tham số này điều khiển chiều cao bước nhảy của các thực thể

Giá trị mặc định được dùng bởi hầu hết các khối là 1.0. Khối mật ong sử dụng hệ số 0.5.