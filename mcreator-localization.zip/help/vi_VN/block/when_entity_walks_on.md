Kích hoạt một quy trình khi một thực thể đi bộ trên khối này.

Nó sẽ không được gọi nếu như thực thể đang đi rón rén.