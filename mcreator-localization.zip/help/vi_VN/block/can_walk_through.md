Nếu tham số này được tích, người chơi sẽ có thể đi xuyên qua nó, giống như cỏ cao và dây leo.

Khối sẽ có hộp đường viền, nhưng nó sẽ không thể va chạm được.