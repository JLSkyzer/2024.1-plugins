Nếu tùy chọn này được tích, khối sẽ được nhuộm một màu cố định khi nó ở trong kho đồ, khớp với loại nhuộm màu.

Màu nhuộm cũng sẽ được áp dụng khi một kết cấu vật phẩm được chỉ định.