Tích tham số này nếu bạn muốn vật phẩm rơi ra khi khối bị phá hủy.

Rương đồ sử dụng tham số này, chẳng hạn.