**Tích hộp này nếu khối của bạn trong suốt** - Không tích để có khối đặc, tích nếu như khối của bạn tương tự lá cây, kính, hàng rào sắt, v.v.

Các loại trong suốt:

* **Đặc:** Không trong suốt (tương tự đất, đá, v.v.)
* **Cutout:** Trong suốt mà không có mipmapping (tương tự kính)
* **Cutout mipped:** Giống như Cutout, nhưng với mipmapping
* **Trong suốt:** Trong suốt một phần và là lựa chọn tốn nhiều tài nguyên nhất (tương tự băng)