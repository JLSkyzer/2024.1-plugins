Tham số này xác định vật phẩm hoặc khối tùy chỉnh được rơi ra khi khối này được đào/phá hủy.

Nếu cấp độ thu hoạch được dùng, chỉ các công cụ với cấp độ thu hoạch thích hợp sẽ khiến cho khối rơi ra vật rơi.