Tham số này xác định loại công cụ bạn cần dùng để phá khối.

Quặng dùng cuốc chim tại đây, thân cây - rìu, đất - xẻng.

Nếu đặt thành "Không xác định", người chơi sẽ có thể phá khối này bằng tay.
