Đặt số lượng mạch quặng sinh ra mỗi đoạn khúc.

Giá trị nhóm quặng Vanilla mỗi đoạn khúc:

* Quặng than - 20
* Quặng sắt - 20
* Quặng vàng - 2
* Quặng redstone - 8
* Quặng kim cương - 1
* Ngọc lưu ly - 1