Tham số này điều khiển tốc độ của thực thể trên khối này.

Giá trị mặc định được sử dụng bởi hầu hết các khối là 1.0. Khối cát linh hồn và khối mật ong là 0.4.