Tham số này điều khiển số lượng khối trung bình mỗi mạch quặng.

Các kích cỡ nhóm quặng Vanilla:

* Quặng than - 17
* Quặng sắt - 9
* Quặng vàng - 9
* Quặng redstone - 8
* Quặng kim cương - 8
* Ngọc lưu ly - 7