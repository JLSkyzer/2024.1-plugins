Tham số này điều khiển khoảng chiều cao Y mà khối này có thể khởi tạo.

Các khoảng chiều cao khởi tạo vanilla:
* Quặng than - 0 đến 256
* Quặng đồng - -16 đến 112
* Quặng sắt - -32 đến 256
* Quặng vàng - -64 đến 32
* Quặng redstone - -64 đến 32
* Quặng kim cương - -64 đến 16
* Quặng ngọc lục bảo - -16 đến 256
* Quặng ngọc lưu ly - -64 đến 64