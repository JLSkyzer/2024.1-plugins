Danh sách các khối mà khối này có thể thay thế khi khởi tạo.

Nếu bạn để danh sách này trống, khối sẽ không được khởi tạo tự nhiên do nó không thể đặt chính nó trên thế giới.