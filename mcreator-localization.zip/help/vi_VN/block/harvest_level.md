Đây là hạng của công cụ cần dùng để phá khối này.

* 0 là gỗ
* 1 là đá
* 2 là sắt
* 3 là kim cương.
* 4 là netherit

Chỉ công cụ với hạng mà bạn chỉ định sẽ có thể phá khối của bạn. Bạn cũng có thể chỉ định các hạng cao hơn netherit bằng việc đặt hạng thành 4 hoặc cao hơn.

Điều kiện để khối rơi ra vật phẩm khi bị phá là:

`NẾU CẤP ĐỘ THU HOẠCH KHỐI <= CẤP ĐỘ THU HOẠCH CÔNG CỤ`
