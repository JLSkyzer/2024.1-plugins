Chọn mô hình mà khối sẽ sử dụng. Mô hình chỉ xác định hình dạng bên ngoài chứ không phải hộp đường viền của khối.

* **Bình thường** - Khối thường với kết cấu ở mỗi mặt
* **Kết cấu đơn** - Khối với kết cấu giống nhau ở mọi mặt
* **Chéo** - Mô hình được dùng bởi thực vật
* Tùy chỉnh - bạn cũng có thể dùng JSON tùy chỉnh và mô hình OBJ

Khi tạo các mô hình tùy chỉnh, JSON được khuyên dùng do sự hỗ trợ của Vanilla đối với loại mô hình này.