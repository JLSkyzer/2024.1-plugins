Nếu được tích, mob này sẽ biến mất khi người chơi di chuyển đủ xa (hành vi mặc định đối với hầu hết các mob).

Tắt cái này đối với boss và mob triệu hồi được để tránh chúng biến mất.