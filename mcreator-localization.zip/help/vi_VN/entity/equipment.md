Cho phép mob có dụng cụ nếu như mô hình mob hỗ trợ nó.

Từ trái qua phải các ô tượng trưng cho tay phải, rồi đến tay trái, rồi đến đầu, áo, quần, ủng.