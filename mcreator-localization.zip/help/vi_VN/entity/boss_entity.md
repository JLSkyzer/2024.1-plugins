Nếu được tích thực thể của bạn sẽ trở thành boss.

Tham số màu điều khiển màu của thanh boss, tương tự với diện mạo thanh.