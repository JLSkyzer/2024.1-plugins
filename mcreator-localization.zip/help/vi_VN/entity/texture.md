Kết cấu của thực thể của bạn. Chắc chắn rằng kết cấu đó tương thích với mô hình bạn chọn.

Các mô hình hai chân, chẳng hạn, chỉ hỗ trợ các kết cấu loại hai chân 64x64 (64x32 trước Minecraft 1.18).