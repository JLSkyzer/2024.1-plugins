Nếu tham số này được tích, màu thứ nhất sẽ là màu nền của quả trứng. Màu thứ hai sẽ là màu đường viền quả trứng.

Bạn cũng có thể chọn tab sáng tạo cho trứng sinh đẻ.