Khối/vật phẩm mà mob sẽ rơi ra khi nó chết.

Bạn có thể dùng bảng loot để có thêm vật rơi, và xác định độ hiếm của mỗi vật rơi.