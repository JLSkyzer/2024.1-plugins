Giá trị tối thiểu và tối đa được chỉ định ở đây xác định kích cỡ nhóm mà thực thể sẽ sinh ra.

Nên nhớ rằng các thực thể sẽ khó có thể sinh ra trong nhóm hơn 20 (các nhóm đó sẽ hiếm khi sinh ra).