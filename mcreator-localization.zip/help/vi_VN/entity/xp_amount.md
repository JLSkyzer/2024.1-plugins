Tham số này điều khiển số lượng kinh nghiệm nhận được khi giết mob.

Thông thường tham số này là 1-3 với động vật và 5 với quái vật.