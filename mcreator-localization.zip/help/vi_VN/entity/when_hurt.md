Trình kích hoạt này kích hoạt quy trình khi thực thể bị thương.

Phần phụ thuộc `sourceentity` trong trường hợp này là thực thể gây ra sát thương cho thực thể này và có thể là vô giá trị nếu sát thương được gây ra bởi một nguồn không phải thực thể.