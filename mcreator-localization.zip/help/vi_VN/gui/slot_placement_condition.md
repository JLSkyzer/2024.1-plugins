Nếu điều kiện thỏa mãn, người chơi sẽ không thể đặt vật phẩm vào ô này. Dù vậy, họ vẫn có thể lấy vật phẩm ra mà không có hạn chế.

Lưu ý: Điều kiện này ghi đè tham số "Hạn chế nhập stack".