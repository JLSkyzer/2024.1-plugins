Nếu được tích, mô hình thực thể được hiển thị sẽ xoay theo vị trí của con trỏ chuột.

Chuyển động của con chuột sẽ được thêm vào giá trị xoay cố định.