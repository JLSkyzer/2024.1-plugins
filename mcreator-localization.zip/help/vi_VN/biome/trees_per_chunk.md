Tham số này điều khiển số lượng cây (loại bạn chọn) mỗi đoạn khúc quần xã.

Đặt thành 0 để vô hiệu hóa cây.