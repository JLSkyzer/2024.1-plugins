Tham số này điều khiển chiều cao tối thiểu của thân cây khi được khởi tạo.

Chỉ được áp dụng khi định nghĩa cây tùy chỉnh được chọn.