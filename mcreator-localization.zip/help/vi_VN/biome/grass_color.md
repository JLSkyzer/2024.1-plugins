Tham số này điều khiển màu của cỏ trong quần xã này.

Tham số này cũng thay đổi màu của các cây cối khác (tán lá).