Khả năng xuất hiện hạt hiệu ứng.

LƯU Ý: Giá trị này được chia cho 100 trong mã code.