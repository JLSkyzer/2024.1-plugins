Tham số này điều khiển nhiệt độ khí hậu của quần xã.

0.0 sẽ giống như Rừng băng tuyết, và 2.0 sẽ giống như Sa mạc.

* Các giá trị thấp hơn 0.15 sẽ khiến cho quần xã tùy chỉnh có tuyết rơi khi trời mưa
* Các giá trị trong khoảng 0.15 đến 1.5 sẽ khiến cho quần xã có mưa
* Các giá trị lớn hơn 1.5 sẽ khiến cho quần xã trở nên khô cằn (vô hiệu hóa trời mưa, sa mạc là một ví dụ)