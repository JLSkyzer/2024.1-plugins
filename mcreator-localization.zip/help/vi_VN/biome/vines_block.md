Tham số này xác định khối dùng để thay thế cây dây leo.

Chọn khối không khí để không có cây dây leo.