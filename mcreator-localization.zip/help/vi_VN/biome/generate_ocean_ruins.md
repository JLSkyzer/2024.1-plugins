Chọn cài đặt này để có tàn tích đại dương trong biome của bạn.
* NONE: Không tàn tích đại dương nào sẽ được khởi tạo.
* COLD: Tàn tích đại dương làm bằng đá sẽ được khởi tạo
* WARM: Tàn tích đại dương làm bằng đá cát sẽ được khởi tạo