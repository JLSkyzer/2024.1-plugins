Các tính năng mặc định là các tính năng được cấu hình sẵn (Các tính năng Minecraft) bạn có thể dùng trong quần xã của bạn.
