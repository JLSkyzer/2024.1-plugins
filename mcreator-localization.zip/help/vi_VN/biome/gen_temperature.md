Tham số này điều khiển sự khởi tạo quần xã chứ không phải khí hậu.

Các quần xã với nhiệt độ tương đương sẽ khởi tạo gần nhau và sẽ tranh cùng một vị trí trong thế giới khi khởi tạo. Các giá trị quá giống nhau sẽ khiến cho một số quần xã không được khởi tạo.

Trong khi các giá trị từ -2 đến 2 là hợp lệ, các quần xã vanilla chỉ dùng các giá trị trong khoảng từ -1 đến 1.

Các quần xã Vanilla ở thế giới thực sẽ dùng các khoảng giá trị sau:

* -1.0 đến -0.45
* -0.45 đến -0.15
* -0.15 đến 0.2
* 0.2 đến 0.55
* 0.5 đến 1.0