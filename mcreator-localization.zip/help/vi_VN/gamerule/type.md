Đây là loại luật chơi. Bạn cần chọn loại phù hợp nhất với (các) ý định của bạn
* Loại số có nghĩa là luật chơi chỉ có thể được thay đổi thành một số (số nguyên)
* Loại logic có nghĩa là luật chơi chỉ có thể là một boolean (đúng hoặc sai)