Tham số này xác định phím dùng để thực thi quy trình phím được gắn.

Người chơi luôn có thể thay đổi nó trong mục Điều khiển.