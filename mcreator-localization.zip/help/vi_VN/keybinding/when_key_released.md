Quy trình này sẽ được thực thi khi phím được chọn được thả ra (sau khi người chơi nhấn phím).

Bạn có thể dùng loại phụ thuộc pressdms để xác định khoảng thời gian mà phím đã được nhấn trong các quy trình tùy chỉnh của bạn.