Danh mục phím được gắn là danh mục được hiển thị trong mục điều khiển của cài đặt Minecraft.

Tất cả các phím được gắn thuộc cùng một danh mục nên có cùng khóa danh mục.

Để thực sự đặt tên danh mục, hãy chuyển đến **${l10n.t("tab.workspace")} -> ${l10n.t("workspace.category.localization")} -> ${l10n.t("workspace.localization.add_entry")}** và dùng `key.category.${data.keyBindingCategoryKey}` cho tên mục và sau đó đặt giá trị thành tên danh mục mong muốn.