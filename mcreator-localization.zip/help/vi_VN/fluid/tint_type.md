Tùy chọn này sẽ nhuộm màu chất lỏng dựa trên màu của quần xã, tương tự như cỏ, lá cây, và nước. Để có kết quả tốt nhất, chất lỏng nên dùng kết cấu thang độ xám.

Loại màu cũng ảnh hưởng đến kết cấu tự động tạo của xô.