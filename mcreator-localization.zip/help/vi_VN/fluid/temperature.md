Đây là nhiệt độ của chất lỏng của bạn, được đo bằng độ Kelvin. Giá trị càng cao, chất lỏng sẽ càng nóng hơn.

Giá trị mặc định là 300K, tương đương với nhiệt độ phòng.