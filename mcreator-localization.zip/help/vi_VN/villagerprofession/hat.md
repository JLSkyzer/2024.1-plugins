Tham số này chỉ định loại mũ được định ra bởi kết cấu nghề nghiệp được chọn, sau đó xác định liệu dân làng vẫn sẽ đội mũ được chỉ định bởi loại của họ sau khi nhận nghề nghiệp này:
* **Không có:** Trong mọi trường hợp;
* **Một phần:** Trong trường hợp nó không che hết đầu của dân làng;
* **Đầy đủ:** Không trường hợp nào.

Điều kiện này có thể được thể hiện thông qua bảng sau (với TH là mũ phụ thuộc vào loại và PH là mũ nghề nghiệp):

| Hiển thị TH   | TH = Không có | TH = Một phần | TH = Đầy đủ |
| ------------- |:-------------:|:-------------:|:-----------:|
| PH = Không có |     Hiện      |     Hiện      |    Hiện     |
| PH = Một phần |     Hiện      |     Hiện      |     Ẩn      |
| PH = Đầy đủ   |      Ẩn       |      Ẩn       |     Ẩn      |