Khối được sử dụng làm khối làm việc của các dân làng của nghề nghiệp này.

Nếu hai mod chỉ định cùng một khối nghề nghiệp, hoặc mod khác dùng POI với khối này cho một số tính năng khác, nghề nghiệp sẽ không hoạt động. Do vậy, hãy chắc rằng khối được sử dụng là duy nhất.