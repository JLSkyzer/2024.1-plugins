Nhấp vào danh sách thả xuống và chọn "danh mục" của bảng loot. Nó không xác định loại bảng loot.

Điều đó chỉ là để tiêu chuẩn hóa tên bảng loot. Dùng blocks/tên_đăng_kí cho các bảng loot khối chẳng hạn.