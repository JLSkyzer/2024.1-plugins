Khi một thực thể đội mũ, quy trình sẽ được thực thi mỗi tick.

Thực thể thỏa mãn là thực thể đang mặc bộ giáp, itemstack thỏa mãn là itemstack của bộ giáp.