Độ phổ biến của những phù phép hiếm có thể được phù phép lên bộ giáp này. Độ phù phép càng cao, phù phép bạn nhận được khi phù phép bộ giáp sẽ càng tốt.

Các giá trị Vanilla:

* Bộ giáp da: 15
* Bộ giáp xích: 12
* Bộ giáp sắt: 9
* Bộ giáp vàng: 25
* Bộ giáp kim cương: 10
* Bộ giáp Netherire: 15