Độ cứng chắc là một giá trị mà sẽ tăng mức độ bảo vệ của bộ giáp.

Bộ giáp Kim cương có độ cứng chắc là 2.0 (tổng cộng là 8.0) và bộ giáp Netherit có độ cứng chắc là 3.0 (tổng cộng là 12.0).