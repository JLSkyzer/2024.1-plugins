Khi một thực thể đeo ủng, quy trình sẽ được thực thi mỗi tick.

Thực thể thỏa mãn là thực thể đang mặc bộ giáp, itemstack thỏa mãn là itemstack của bộ giáp.