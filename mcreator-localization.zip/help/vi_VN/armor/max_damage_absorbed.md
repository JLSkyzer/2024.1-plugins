Tham số này xác định độ bền của bộ giáp và được áp dụng như sau:

* mũ: thiệt_hại_được_hấp_thụ_tối_đa * 13
* áo: thiệt_hại_được_hấp_thụ_tối_đa * 15
* quần: thiệt_hại_được_hấp_thụ_tối_đa * 16
* ủng: thiệt_hại_được_hấp_thụ_tối_đa * 11

Bộ giáp Vanilla sử dụng các hệ số sau:

* Bộ giáp da: 5
* Bộ giáp xích: 15
* Bộ giáp vàng: 7
* Bộ giáp kim cương: 33
* Bộ giáp Netherire: 37