Tham số này xác định cách nhãn sẽ hoạt động.

* **forge:** là một sự thay thế cho Từ điển Quặng với các nhãn. Chúng có thể được dùng để cấp cho những người tạo mod khác quyền truy cập vào mod của bạn nếu bạn cung cấp cho họ tên nhãn.
* **minecraft:** được dùng để thêm các khối hoặc vật phẩm tùy chỉnh vào các nhóm nhãn vanilla. Chẳng hạn, thêm các thân cây từ mod của bạn vào nhóm thân cây của Minecraft (bằng cách đặt tên thành "logs" và namespace thành "minecraft").
* **mod:** được dùng để nhóm các phần tử mod trong mod của bạn để sử dụng nội bộ.