Đây là tên đăng kí của nhãn của bạn.

Tên mà bạn viết vào trường này sẽ là tên mà bạn cần phải viết để có thể sử dụng nhãn của bạn.

Khi mở rộng các nhóm nhãn vanilla, hãy dùng các tên nhãn vanilla thích hợp tại đây và dùng namespace "minecraft".