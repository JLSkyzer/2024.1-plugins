Nếu tham số này được tích, nguồn ánh sáng toàn cầu sẽ bị vô hiệu hóa và chiều không gian sẽ trở nên tối.

Kể cả khi ánh sáng bầu trời được tắt, chiều không gian này sẽ không có nguồn ánh sáng tự nhiên.

Giữ ánh sáng bầu trời được bật cho các chiều không gian nether trong mọi trường hợp, trừ khi chiều không gian nên được để tối hoàn toàn.