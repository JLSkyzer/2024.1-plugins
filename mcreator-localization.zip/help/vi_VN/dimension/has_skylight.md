Tham số này sẽ làm cho chiều không gian có ánh sáng bầu trời tương tự thế giới thực với thời gian trôi đi.

Lưu ý rằng ánh sáng bầu trời không thể đi xuyên qua khối, vậy nên các chiều không gian nether với ánh sáng bầu trời vẫn sẽ trở nên tối tăm và cần có Nguồn ánh sáng toàn cầu được kích hoạt để không trở nên tối.