Quy trình này sẽ được thục thi khi một người choi rời một chiều không gian.
