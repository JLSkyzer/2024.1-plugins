Tích tham số này để kích hoạt sương mù dày đặc cho chiều không gian, kể cả khi khoảng cách kết xuất được đặt ở một giá trị lớn. Một ví dụ cho điều này có thể được nhìn thấy trong Nether.
