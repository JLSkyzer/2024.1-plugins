Dùng trường này để xác định các chiều không gian, nơi mà sự sinh đẻ nên xảy ra.

Nếu danh sách trống, không hạn chế chiều không gian nào sẽ được đặt và sự sinh đẻ sẽ xảy ra ở mọi chiều không gian.