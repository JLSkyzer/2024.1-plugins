Thêm một quy trình với giá trị trả về logic để có thêm điều kiện cho sự khởi tạo của tính năng này.

Điều kiện này được kiểm tra SAU công cụ sửa đổi sự sắp đặt trong trình dựng tính năng.

Lưu ý rằng một vài khối quy trình có thể không hoạt động chính xác trong trình kích hoạt này trong quá trình khởi tạo thể giới sớm.