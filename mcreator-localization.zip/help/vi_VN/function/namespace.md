* **Mod:** Chỉ được dùng với mod của bạn (Gọi một chức năng như vậy với `${modid}:${registryname}`)

* **Minecraft:** Được dùng với một số tùy chọn của Minecraft (Gọi một chức năng như vậy với `minecraft:${registryname}`)