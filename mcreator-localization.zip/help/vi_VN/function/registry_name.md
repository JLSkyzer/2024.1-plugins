Bạn có thể đặt tên cho chức năng của bạn bằng một từ hay nhiều hơn với (các) dấu gạch dưới.

Ví dụ:
* thành_tựu
* phần_thưởng_thành_tựu_quần_xã