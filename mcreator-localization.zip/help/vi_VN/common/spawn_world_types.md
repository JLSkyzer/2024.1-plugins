Dùng trường này để xác định nơi mà sự sinh đẻ sẽ xảy ra.

Nếu danh sách này trống, sự sinh đẻ sẽ bị vô hiệu hóa.