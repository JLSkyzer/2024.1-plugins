Dùng trường này để xác định sự sinh đẻ sẽ diễn ra trên (các) khối nào.

Nếu danh sách này trống, tùy chọn này sẽ bị tắt, và sự sinh đẻ sẽ xảy ra trên tất cả các khối.