Đây là nơi khối của bạn sẽ ở trong chế độ sáng tạo.

Dùng tab với tiền tố CUSTOM: để dùng tab tùy chỉnh.