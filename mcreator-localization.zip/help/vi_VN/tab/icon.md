Biểu tượng để nhận dạng tab sáng tạo như bột redstone cho tab redstone.

Chỉ có vật phẩm được hỗ trợ ở đây. Những khối không đi với vật phẩm không thể được hiển thị như biểu tượng.