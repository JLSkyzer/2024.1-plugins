Chọn mô hình để mà vật phẩm sẽ sử dụng. Mô hình chỉ xác định hình dạng bên ngoài.

* **Bình thường** - Vật phẩm thường
* Công cụ - Mô hình được dùng bởi các công cụ
* Tùy chỉnh - bạn cũng có thể dùng JSON tùy chỉnh và mô hình OBJ

Khi tạo các mô hình tùy chỉnh, JSON được khuyên dùng do sự hỗ trợ của Vanilla đối với loại mô hình này.