Giá trị dinh dưỡng là lượng thức ăn sẽ được cung cấp cho người chơi.

1 là 1/2 thanh thức ăn. 20 là đầy thanh thức ăn.