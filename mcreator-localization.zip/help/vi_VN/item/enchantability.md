Độ phổ biến của những phù phép hiếm có thể được phù phép lên vật phẩm/công cụ này. Độ phù phép càng cao, phù phép bạn nhận được khi phù phép vật phẩm/công cụ sẽ càng tốt.

Các giá trị Vanilla:

* Công cụ gỗ: 15
* Công cụ đá: 5
* Công cụ sắt: 14
* Công cụ vàng: 22
* Công cụ kim cương: 10
* Công cụ netherit: 15
* Sách: 1