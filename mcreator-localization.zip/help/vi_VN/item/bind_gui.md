Chọn GUI của bạn tại đây để bật kho đồ và gán GUI vào vật phẩm này.

Đặt thành Trống để tắt kho đồ (bạn muốn điều này trong hầu hết các trường hợp).

Bật kho đồ sẽ khiến cho vật phẩm này không thể xếp chồng được.