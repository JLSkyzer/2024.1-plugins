Tham số này điều khiển độ bền của vật phẩm (vật phẩm có thể được sử dùng bao nhiêu lần).

Đặt giá trị này thành 0 để vô hiệu hóa cơ chế đếm lần sử dụng của vật phẩm được cho.

Các giá trị Vanilla để tham khảo:

* Vàng: 32 lần
* Gỗ: 59 lần
* Đá: 131 lần
* Sắt: 250 lần.
* Kim cương: 1561 lần
* Netherit: 2031 lần
* Cần câu cá: 64 lần
* Dụng cụ đánh lửa: 64 lần
* Cần câu gắn cà rốt: 25 lần
* Kéo tỉa: 238 lần
* Đinh ba: 250 lần
* Nỏ: 326 lần
* Khiên: 336 lần
* Cung: 384 lần
* Cánh cứng: 432 lần