Tham số tốc độ phá hủy điều khiển tốc độ vật phẩm này phá hủy các khối.

Các giá trị điển hình:
* **1** - vật phẩm thường
* **1.5** kiếm
* **2>** công cụ gặt hái