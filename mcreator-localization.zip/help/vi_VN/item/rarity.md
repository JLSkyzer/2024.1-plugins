Độ hiếm chỉ ảnh hưởng đến màu của tên vật phẩm.
* Phổ biến: Trắng
* Không phổ biến: Vàng
* Hiếm: Lục lam
* Cực hiếm: Tím nhạt