Người chơi cần phải có, ít nhất, cấp độ quyền hạn này để thực thi lệnh.

Bạn cũng có thể tắt yêu cầu quyền hạn. Trong trường hợp này, lệnh vẫn sẽ hoạt động kể cả khi gian lận đã bị vô hiệu hóa trong một thế giới đã cho.

1 là cấp độ quyền hạn cơ bản nhất, và 4 là cấp độ cao nhất (cấp độ điều hành máy chủ).

Xem [trang này](https://mcreator.net/wiki/command-permission-levels) để biết những lệnh nào có thể được thực thi với mỗi cấp độ quyền hạn.