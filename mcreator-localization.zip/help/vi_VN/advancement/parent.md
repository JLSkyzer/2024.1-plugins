Đây là thành tựu mà thành tựu của bạn sẽ được liệt kê sau đó.

Bạn có thể dùng "No parent: root" để tạo ra một nhánh mới (tab thành tựu mới).