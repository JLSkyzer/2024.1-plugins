Biểu tượng hiển thị trên tab thành tựu.

Nếu đây là gốc thì nó cũng sẽ là biểu tượng của thành tựu.

Chỉ có vật phẩm được hỗ trợ ở đây. Những khối không đi với vật phẩm không thể được hiển thị như biểu tượng.