Đây là loại của thành tựu

* Nhiệm vụ là loại một loại thành tích thông thường và phổ biến nhất.
* Mục tiêu là một mục tiêu dài hạn mà bạn cố gắng để hoàn thành.
* Thử thách là để kiểm tra một người chơi hay thách thức họ một thứ gì đó.