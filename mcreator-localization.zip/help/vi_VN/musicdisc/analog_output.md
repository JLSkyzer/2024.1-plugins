Giá trị redstone tương tự được xuất ra từ mạch so sánh khi đĩa nhạc này được chơi trong máy phát nhạc bên cạnh nó.
