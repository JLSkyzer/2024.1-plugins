Độ dài của đĩa nhạc với đơn vị là tick. 20 tick là một giây.

Tham số này được dùng để báo cho các Allay dùng nhảy múa khi một khoảng tick được chỉ định trong trường này trôi qua từ lúc bắt đầu phát nhạc.
