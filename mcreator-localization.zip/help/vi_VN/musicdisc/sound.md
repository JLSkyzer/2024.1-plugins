Chọn nhạc mà bạn muốn đĩa nhạc chơi trong hộp chơi nhạc.

Để có thể hỗ trợ tất cả những tính năng của hộp chơi nhạc như là âm thanh nhỏ dần theo khoảng cách, hãy chắc chắn rằng âm thanh của bạn ở định dạng MONO.

Nếu bạn có ý định phân phối bản mod, hãy chắc rằng bạn có được sự cho phép để phân phối lại bản nhạc mà bạn dùng!