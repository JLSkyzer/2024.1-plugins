Tham số này điều khiển tốc độ sử dụng công cụ của bạn.

Thuộc tính này điều khiển độ dài của thời gian cooldown, với thời gian là T = 1 / tốc-độ-Tấn-công * 20ticks.

Hệ số thiệt hại sau đó là 0.2 + ((t + 0.5) / T) ^ 2 * 0.8, giới hạn trong phạm vi 0.2 – 1, trong đó t là số tick từ lần tấn công cuối hay chuyển đổi vật phẩm.