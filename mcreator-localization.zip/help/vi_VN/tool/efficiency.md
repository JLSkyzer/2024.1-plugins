Tham số này xác định tốc độ mà công cụ phá.

Ví dụ: Công cụ đá có hiệu suật thấp hơn công cụ kim cương.

Các giá trị Vanilla:
* Công cụ gỗ có 2.
* Công cụ đá có 4.
* Công cụ sắt có 6.
* Công cụ kim cương có 8.
* Công cụ netherit có 9.
* Công cụ vàng có 12.