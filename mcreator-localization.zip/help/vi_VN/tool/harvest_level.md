Công cụ với cấp độ (hạng) thu hoạch được cho chỉ có thể phá hủy các khối cùng hạng hoặc thấp hơn.

* 0 là tay/gỗ
* 1 là đá
* 2 là sắt
* 3 là kim cương
* 4 là netherit

Bạn cũng có thể chỉ định các hạng cao hơn netherit bằng việc đặt hạng thành 5 hoặc cao hơn.