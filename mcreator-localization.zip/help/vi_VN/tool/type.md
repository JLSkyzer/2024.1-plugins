Loại công cụ của công cụ này.

Một số các tham số dưới đây không được sử dụng bởi một vài loại công cụ.