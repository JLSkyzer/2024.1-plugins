Danh sách này xác định những khối nào mà công cụ có thể sử dụng được.

Tham số này chỉ được sử dụng với loại công cụ đặc biệt.