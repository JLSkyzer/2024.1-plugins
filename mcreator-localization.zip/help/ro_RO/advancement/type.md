Acesta este tipul realizării

* Sarcina este un tip de realizare de bază și este cel mai frecvent.
* Obiectivul este un obiectiv pe termen lung, pe care încercaţi să îl atingeţi.
* Provocarea este să testezi un jucător sau să îl provoci la ceva.