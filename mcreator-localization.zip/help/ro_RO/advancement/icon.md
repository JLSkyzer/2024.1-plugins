Pictograma arată în fila de progrese.

Dacă acesta este părintele rădăcină atunci va fi și pictograma de progresii.

Numai obiectele sunt acceptate aici. Blocurile fără obiect nu pot fi afișate ca pictogramă.