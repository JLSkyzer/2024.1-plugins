Acesta este progresul după care realizarea dvs. va fi enumerată.

Puteți utiliza "Fără părinte: rădăcină" va face o nouă cale (filă de progres nouă).