این پارامتر بلاک زیر بلاک لایه بالایی را کنترل می کند.

به طور کلی، خاک ونیلا یا خاک کاستوم استفاده می کنند.

This block should be tagged in <b>minecraft:dirt</b> Blocks tags for Forge mods for plants and trees to spawn properly in the biome.