این پارامتر بلاکی که بر روی بالاترین لایه بایوم است کنترل می کند.

به طور کلی، بایوم های ونیلا یا کاستوم در اینجا استفاده می شوند.

This block should have GRASS material and be tagged in <b>minecraft:dirt</b> Blocks tags for Forge mods for plants and trees to spawn properly in the biome.